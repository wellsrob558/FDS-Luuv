$(function () {
    function escapeHtml(value) {
        return $('<div>').text(value || '').html();
    }

    function previewForm() {
        var preview = $('#livePreview');
        if (!preview.length) return;

        var html = '';
        var title = $('#title').val() || 'Título do formulário';
        var previewCover = preview.data('cover') || '';
        var coverInput = $('input[name="cover_image"]')[0];
        if (coverInput && coverInput.files && coverInput.files[0] && window.URL && typeof window.URL.createObjectURL === 'function') {
            previewCover = window.URL.createObjectURL(coverInput.files[0]);
        }
        if (previewCover && !$('input[name="remove_cover_image"]').is(':checked')) {
            html += '<img class="preview-cover" src="' + escapeHtml(previewCover) + '" alt="Prévia da capa">';
        }
        var description = $('#description').val() || 'Descrição do formulário';
        html += '<h3>' + escapeHtml(title) + '</h3>';
        html += '<p class="muted">' + escapeHtml(description) + '</p>';

        $('.field-builder-item').each(function (index) {
            var type = $(this).find('.field-type').val();
            var label = $(this).find('.field-label').val() || ('Campo ' + (index + 1));
            var placeholder = $(this).find('.field-placeholder').val() || '';
            var required = $(this).find('.field-required').is(':checked') ? ' <span class="small">* obrigatório</span>' : '';
            var cssClass = $(this).find('.field-class').val() || '';
            var width = $(this).find('.field-width').val() || '100';
            html += '<div class="form-group" style="width:' + width + '%">';
            html += '<label>' + escapeHtml(label) + required + '</label>';
            if (type === 'textarea') {
                html += '<textarea class="' + escapeHtml(cssClass) + '" placeholder="' + escapeHtml(placeholder) + '"></textarea>';
            } else if (type === 'select') {
                html += '<select class="' + escapeHtml(cssClass) + '"><option>Selecione</option></select>';
            } else if (type === 'radio' || type === 'checkbox') {
                html += '<div><label><input type="' + type + '"> Opção 1</label></div>';
            } else {
                html += '<input type="' + type + '" class="' + escapeHtml(cssClass) + '" placeholder="' + escapeHtml(placeholder) + '">';
            }
            html += '</div>';
        });
        html += '<button class="btn" type="button">Enviar</button>';
        preview.html(html);
    }

    function bindPreview() {
        $(document).on('input change', '#title, #description, .field-type, .field-label, .field-placeholder, .field-required, .field-class, .field-width, input[name="cover_image"], input[name="remove_cover_image"]', function () {
            var card = $(this).closest('.field-builder-item');
            var label = card.find('.field-label').val() || 'Campo sem rótulo';
            card.find('.field-builder-top strong').text(label);
            previewForm();
        });
    }

    function fieldBlock(index, existing) {
        existing = existing || {};
        var types = window.formFieldTypes || {};
        var options = '';
        $.each(types, function (key, label) {
            options += '<option value="' + key + '" ' + (existing.field_type === key ? 'selected' : '') + '>' + label + '</option>';
        });
        return '' +
            '<div class="field-builder-item">' +
                '<div class="field-builder-top">' +
                    '<span class="drag-handle" title="Arrastar para ordenar">↕ Arrastar</span>' +
                    '<strong>' + escapeHtml(existing.label || 'Campo sem rótulo') + '</strong>' +
                '</div>' +
                '<div class="grid grid-3">' +
                    '<div class="form-group"><label>Tipo</label><select name="fields[' + index + '][field_type]" class="field-type">' + options + '</select></div>' +
                    '<div class="form-group"><label>Nome interno</label><input type="text" name="fields[' + index + '][name]" value="' + escapeHtml(existing.name || '') + '" required></div>' +
                    '<div class="form-group"><label>Rótulo</label><input type="text" name="fields[' + index + '][label]" class="field-label" value="' + escapeHtml(existing.label || '') + '" required></div>' +
                    '<div class="form-group"><label>Placeholder</label><input type="text" name="fields[' + index + '][placeholder]" class="field-placeholder" value="' + escapeHtml(existing.placeholder || '') + '"></div>' +
                    '<div class="form-group"><label>Valor padrão</label><input type="text" name="fields[' + index + '][default_value]" value="' + escapeHtml(existing.default_value || '') + '"></div>' +
                    '<div class="form-group"><label>Máscara</label><input type="text" name="fields[' + index + '][mask]" value="' + escapeHtml(existing.mask || '') + '"></div>' +
                    '<div class="form-group"><label>Validação Regex</label><input type="text" name="fields[' + index + '][validation_rule]" value="' + escapeHtml(existing.validation_rule || '') + '"></div>' +
                    '<div class="form-group"><label>Classe CSS</label><input type="text" name="fields[' + index + '][css_class]" class="field-class" value="' + escapeHtml(existing.css_class || '') + '"></div>' +
                    '<div class="form-group"><label>Largura (%)</label><input type="number" min="10" max="100" name="fields[' + index + '][width]" class="field-width" value="' + escapeHtml(existing.width || '100') + '"></div>' +
                    '<div class="form-group"><label>Ordem (automática)</label><input type="number" min="0" name="fields[' + index + '][sort_order]" class="js-sort-order" value="' + (existing.sort_order || index) + '" readonly></div>' +
                    '<div class="form-group"><label>Opções (valor|rótulo)</label><textarea name="fields[' + index + '][options_text]">' + escapeHtml(existing.options_text || '') + '</textarea></div>' +
                    '<div class="form-group inline"><label><input type="checkbox" class="field-required" name="fields[' + index + '][is_required]" ' + (parseInt(existing.is_required || 0, 10) ? 'checked' : '') + '> Obrigatório</label></div>' +
                    '<div class="form-group inline"><label><input type="checkbox" name="fields[' + index + '][is_active]" ' + ((existing.is_active === undefined || parseInt(existing.is_active, 10) === 1) ? 'checked' : '') + '> Ativo</label></div>' +
                    (existing.id ? '<input type="hidden" name="fields[' + index + '][id]" value="' + existing.id + '">' : '') +
                '</div>' +
                '<div class="actions"><button type="button" class="btn btn-light remove-field">Remover</button></div>' +
            '</div>';
    }

    function reindexFieldBlocks() {
        $('#fieldsContainer .field-builder-item').each(function (index) {
            $(this).find('input, select, textarea').each(function () {
                var name = $(this).attr('name');
                if (!name) return;
                $(this).attr('name', name.replace(/fields\[\d+\]/, 'fields[' + index + ']'));
            });
            $(this).find('.js-sort-order').val(index + 1);
            var label = $(this).find('.field-label').val() || 'Campo sem rótulo';
            $(this).find('.field-builder-top strong').text(label);
        });
    }

    function setupSortable() {
        var container = $('#fieldsContainer');
        if (!container.length || !$.fn.sortable) return;
        container.sortable({
            handle: '.drag-handle',
            placeholder: 'field-builder-placeholder',
            update: function () {
                reindexFieldBlocks();
                previewForm();
            }
        });
    }

    $('#addField').on('click', function () {
        var container = $('#fieldsContainer');
        var idx = container.children('.field-builder-item').length;
        container.append(fieldBlock(idx));
        reindexFieldBlocks();
        previewForm();
    });

    $(document).on('click', '.remove-field', function () {
        $(this).closest('.field-builder-item').remove();
        reindexFieldBlocks();
        previewForm();
    });

    bindPreview();
    setupSortable();
    reindexFieldBlocks();
    previewForm();

    $('#formBuilder').data('fieldBlock', fieldBlock);

    $('.js-confirm').on('click', function () {
        return confirm($(this).data('confirm') || 'Tem certeza?');
    });

    $('.public-form').on('submit', function () {
        var valid = true;
        $(this).find('[data-required="1"]').each(function () {
            if (!$(this).val()) {
                alert('Preencha o campo obrigatório: ' + ($(this).data('label') || 'Campo'));
                $(this).focus();
                valid = false;
                return false;
            }
        });
        return valid;
    });

    $('[data-chart]').each(function () {
        var raw = $(this).attr('data-chart');
        if (!raw || typeof Chart === 'undefined') return;
        var config = JSON.parse(raw);
        new Chart(this.getContext('2d'), config);
    });
});
