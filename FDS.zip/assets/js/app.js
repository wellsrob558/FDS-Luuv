$(function () {
    function previewForm() {
        var preview = $('#livePreview');
        if (!preview.length) return;

        var html = '';
        var title = $('#title').val() || 'Título do formulário';
        var description = $('#description').val() || 'Descrição do formulário';
        html += '<h3>' + $('<div>').text(title).html() + '</h3>';
        html += '<p class="muted">' + $('<div>').text(description).html() + '</p>';

        $('.field-builder-item').each(function (index) {
            var type = $(this).find('.field-type').val();
            var label = $(this).find('.field-label').val() || ('Campo ' + (index + 1));
            var placeholder = $(this).find('.field-placeholder').val() || '';
            var required = $(this).find('.field-required').is(':checked') ? ' <span class="small">* obrigatório</span>' : '';
            var cssClass = $(this).find('.field-class').val() || '';
            var width = $(this).find('.field-width').val() || '100';
            html += '<div class="form-group" style="width:' + width + '%">';
            html += '<label>' + $('<div>').text(label).html() + required + '</label>';
            if (type === 'textarea') {
                html += '<textarea class="' + cssClass + '" placeholder="' + $('<div>').text(placeholder).html() + '"></textarea>';
            } else if (type === 'select') {
                html += '<select class="' + cssClass + '"><option>Selecione</option></select>';
            } else if (type === 'radio' || type === 'checkbox') {
                html += '<div><label><input type="' + type + '"> Opção 1</label></div>';
            } else {
                html += '<input type="' + type + '" class="' + cssClass + '" placeholder="' + $('<div>').text(placeholder).html() + '">';
            }
            html += '</div>';
        });
        html += '<button class="btn" type="button">Enviar</button>';
        preview.html(html);
    }

    function bindPreview() {
        $(document).on('input change', '#title, #description, .field-type, .field-label, .field-placeholder, .field-required, .field-class, .field-width', previewForm);
    }

    function fieldBlock(index, existing) {
        existing = existing || {};
        var types = window.formFieldTypes || {};
        var options = '';
        $.each(types, function (key, label) {
            options += '<option value="' + key + '" ' + (existing.field_type === key ? 'selected' : '') + '>' + label + '</option>';
        });
        return '' +
            '<div class="field-builder-item">' +
                '<div class="grid grid-3">' +
                    '<div class="form-group"><label>Tipo</label><select name="fields[' + index + '][field_type]" class="field-type">' + options + '</select></div>' +
                    '<div class="form-group"><label>Nome interno</label><input type="text" name="fields[' + index + '][name]" value="' + (existing.name || '') + '" required></div>' +
                    '<div class="form-group"><label>Rótulo</label><input type="text" name="fields[' + index + '][label]" class="field-label" value="' + (existing.label || '') + '" required></div>' +
                    '<div class="form-group"><label>Placeholder</label><input type="text" name="fields[' + index + '][placeholder]" class="field-placeholder" value="' + (existing.placeholder || '') + '"></div>' +
                    '<div class="form-group"><label>Valor padrão</label><input type="text" name="fields[' + index + '][default_value]" value="' + (existing.default_value || '') + '"></div>' +
                    '<div class="form-group"><label>Máscara</label><input type="text" name="fields[' + index + '][mask]" value="' + (existing.mask || '') + '"></div>' +
                    '<div class="form-group"><label>Validação Regex</label><input type="text" name="fields[' + index + '][validation_rule]" value="' + (existing.validation_rule || '') + '"></div>' +
                    '<div class="form-group"><label>Classe CSS</label><input type="text" name="fields[' + index + '][css_class]" class="field-class" value="' + (existing.css_class || '') + '"></div>' +
                    '<div class="form-group"><label>Largura (%)</label><input type="number" min="10" max="100" name="fields[' + index + '][width]" class="field-width" value="' + (existing.width || '100') + '"></div>' +
                    '<div class="form-group"><label>Ordem</label><input type="number" min="0" name="fields[' + index + '][sort_order]" value="' + (existing.sort_order || index) + '"></div>' +
                    '<div class="form-group"><label>Opções (valor|rótulo)</label><textarea name="fields[' + index + '][options_text]">' + (existing.options_text || '') + '</textarea></div>' +
                    '<div class="form-group inline"><label><input type="checkbox" class="field-required" name="fields[' + index + '][is_required]" ' + (parseInt(existing.is_required || 0, 10) ? 'checked' : '') + '> Obrigatório</label></div>' +
                    '<div class="form-group inline"><label><input type="checkbox" name="fields[' + index + '][is_active]" ' + ((existing.is_active === undefined || parseInt(existing.is_active, 10) === 1) ? 'checked' : '') + '> Ativo</label></div>' +
                    (existing.id ? '<input type="hidden" name="fields[' + index + '][id]" value="' + existing.id + '">' : '') +
                '</div>' +
                '<div class="actions"><button type="button" class="btn btn-light remove-field">Remover</button></div>' +
            '</div>';
    }

    $('#addField').on('click', function () {
        var container = $('#fieldsContainer');
        var idx = container.children('.field-builder-item').length;
        container.append(fieldBlock(idx));
        previewForm();
    });

    $(document).on('click', '.remove-field', function () {
        $(this).closest('.field-builder-item').remove();
        previewForm();
    });

    bindPreview();
    previewForm();

    $('#formBuilder').data('fieldBlock', fieldBlock);

    $('.js-confirm').on('click', function () {
        return confirm($(this).data('confirm') || 'Tem certeza?');
    });

    $('.public-form').on('submit', function () {
        var valid = true;
        $(this).find('[data-required="1"]').each(function () {
            if (!$(this).val()) {
                alert('Preencha o campo obrigatório: ' + ($(this).data('label') || 'Campo'));
                $(this).focus();
                valid = false;
                return false;
            }
        });
        return valid;
    });
});
