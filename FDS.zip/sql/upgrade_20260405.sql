USE dynamic_forms;

ALTER TABLE forms
    ADD COLUMN max_responses INT NULL AFTER enable_captcha,
    ADD COLUMN available_from DATETIME NULL AFTER max_responses,
    ADD COLUMN available_until DATETIME NULL AFTER available_from;

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NULL,
    description VARCHAR(255) NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_audit_logs_action (action),
    INDEX idx_audit_logs_entity (entity_type, entity_id),
    INDEX idx_audit_logs_created_at (created_at),
    CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE forms ADD COLUMN cover_image VARCHAR(255) NULL AFTER enable_captcha;
