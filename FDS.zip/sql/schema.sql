CREATE DATABASE IF NOT EXISTS dynamic_forms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dynamic_forms;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('super_admin', 'editor', 'viewer') NOT NULL DEFAULT 'editor',
    status TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE forms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(180) NOT NULL,
    slug VARCHAR(180) NOT NULL UNIQUE,
    description TEXT NULL,
    success_message TEXT NULL,
    notify_email VARCHAR(180) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    enable_captcha TINYINT(1) NOT NULL DEFAULT 0,
    cover_image VARCHAR(255) NULL,
    max_responses INT NULL,
    available_from DATETIME NULL,
    available_until DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE form_fields (
    id INT AUTO_INCREMENT PRIMARY KEY,
    form_id INT NOT NULL,
    field_type VARCHAR(30) NOT NULL,
    name VARCHAR(120) NOT NULL,
    label VARCHAR(180) NOT NULL,
    placeholder VARCHAR(255) NULL,
    is_required TINYINT(1) NOT NULL DEFAULT 0,
    default_value TEXT NULL,
    mask VARCHAR(80) NULL,
    validation_rule VARCHAR(255) NULL,
    css_class VARCHAR(120) NULL,
    width INT NOT NULL DEFAULT 100,
    options_json JSON NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_form_fields_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    form_id INT NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    status TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_submissions_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE submission_values (
    id INT AUTO_INCREMENT PRIMARY KEY,
    submission_id INT NOT NULL,
    field_id INT NOT NULL,
    value_text LONGTEXT NULL,
    value_json JSON NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_submission_values_submission FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE,
    CONSTRAINT fk_submission_values_field FOREIGN KEY (field_id) REFERENCES form_fields(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NULL,
    description VARCHAR(255) NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_audit_logs_action (action),
    INDEX idx_audit_logs_entity (entity_type, entity_id),
    INDEX idx_audit_logs_created_at (created_at),
    CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO users (name, email, password_hash, role, status, created_at, updated_at)
VALUES (
    'Administrador',
    'admin@example.com',
    '$2y$12$VYWo7oxIHA00lVE4xkVyBuBKObri5M8UK8Pp4chfXhXCWIuRLYYXG',
    'super_admin',
    1,
    NOW(),
    NOW()
);
