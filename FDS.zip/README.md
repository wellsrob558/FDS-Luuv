# Dynamic Forms System

Sistema web em **PHP + MySQL + jQuery + HTML5 + CSS3 + JavaScript** para criação dinâmica de formulários com CRUD automático das respostas.

## Recursos implementados

- Login administrativo com sessão e controle de acesso por papel (`super_admin`, `editor`, `viewer`)
- Dashboard administrativo com gráficos (Chart.js)
- CRUD de formulários: criar, editar, excluir, duplicar, ativar/desativar
- Builder dinâmico de campos com preview em tempo real
- Reordenação real de campos com drag-and-drop (jQuery UI Sortable)
- Tipos de campo: texto, textarea, número, e-mail, telefone, data, hora, select, radio, checkbox, arquivo, senha e URL
- Configurações por campo: nome interno, rótulo, placeholder, obrigatório, valor padrão, máscara, validação regex, classe CSS, largura, opções, status e ordem
- Configurações por formulário: limite de respostas, data/hora de abertura e data/hora de encerramento
- Painel de usuários com criação, edição, ativação/desativação e exclusão
- Logs de auditoria para ações administrativas e envios públicos
- Modelagem flexível usando `forms`, `form_fields`, `submissions` e `submission_values`
- CRUD automático de respostas por formulário
- Busca, filtros, paginação, ordenação e exportação CSV/Excel
- URL pública por slug amigável
- Validação no front-end (jQuery) e back-end (PHP)
- Sanitização, prepared statements, proteção CSRF e mitigação básica de spam
- Upload de arquivo com whitelist de MIME e limite configurável
- Notificação por e-mail ao receber resposta

## Estrutura

```txt
config/
includes/
assets/
  css/
  js/
  uploads/
admin/
  forms/
  responses/
  users/
auth/
public/
sql/
README.md
index.php
```

## Instalação

1. Copie a pasta para o seu servidor web.
2. Crie um virtual host ou coloque a pasta dentro do diretório público do Apache/Nginx.
3. **Instalação nova:** importe `sql/schema.sql`.
4. **Instalação existente:** execute `sql/upgrade_20260405.sql` no mesmo banco.
5. Ajuste as credenciais em `config/database.php`.
6. Ajuste `BASE_URL` em `config/config.php` para a URL correta do projeto.
7. Garanta permissão de escrita em `assets/uploads/`.

## Login padrão

- **Usuário:** `admin@example.com`
- **Senha:** `123456`

> Recomenda-se alterar imediatamente a senha no banco após o primeiro acesso.

## Observações de modelagem

- A estrutura usa EAV controlado por metadados para permitir evolução do formulário sem quebrar respostas históricas.
- Quando um campo é “removido” na edição, ele é apenas desativado, preservando referências antigas.
- O CRUD de respostas sempre consulta os metadados atuais do formulário, mas os valores históricos permanecem disponíveis.
- O limite de respostas e a janela de publicação são aplicados tanto na listagem pública quanto no endpoint de envio.
- Os logs de auditoria registram ações como login, logout, alterações em formulários, alterações de usuários, exportações e novos envios públicos.


## Extra incluído
- upload de imagem de capa por formulário, com exibição na listagem pública e na página do formulário
