<?php
require_once __DIR__ . '/config/config.php';
if (is_logged_in()) {
    redirect('/admin/dashboard.php');
}
redirect('/auth/login.php');
