<?php
require_once __DIR__ . '/../config/config.php';
if (is_logged_in()) {
    redirect('/admin/dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = post('email');
    $password = $_POST['password'] ?? '';

    if (authenticate($pdo, $email, $password)) {
        audit_log($pdo, 'login', 'session', current_user()['id'], 'Login realizado com sucesso.');
        flash('success', 'Login realizado com sucesso.');
        redirect('/admin/dashboard.php');
    }
    flash('error', 'Credenciais inválidas.');
}

$title = 'Login';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card login-card">
    <div class="page-header">
        <div>
        <img src="logo.png" width="50%" style="border-radius: 5%;"><br><br>
            <h1 class="page-title">Acesso administrativo</h1>
            <p class="muted">Entre para gerenciar formulários dinâmicos.</p>
        </div>
    </div>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <div class="form-group">
            <label>E-mail</label>
            <input type="email" name="email" required value="admin@example.com">
        </div>
        <div class="form-group">
            <label>Senha</label>
            <input type="password" name="password" required value="123456">
        </div>
        <button class="btn" type="submit">Entrar</button>
    </form>
    <p class="small">Usuário padrão do instalador: <span class="kbd">admin@example.com / 123456</span></p>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
