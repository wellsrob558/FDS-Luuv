<?php
require_once __DIR__ . '/../config/config.php';
logout_user();
flash('success', 'Sessão encerrada com sucesso.');
redirect('/auth/login.php');
