<?php
require_once __DIR__ . '/../config/config.php';
if (is_logged_in()) {
    audit_log($pdo, 'logout', 'session', current_user()['id'], 'Logout realizado.');
}
logout_user();
flash('success', 'Sessão encerrada com sucesso.');
redirect('/auth/login.php');
