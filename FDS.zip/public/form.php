<?php
require_once __DIR__ . '/../config/config.php';
$slug = get('slug');
$formStmt = $pdo->prepare('SELECT f.*, (SELECT COUNT(*) FROM submissions s WHERE s.form_id = f.id) AS responses_count FROM forms f WHERE slug = :slug LIMIT 1');
$formStmt->execute([':slug' => $slug]);
$form = $formStmt->fetch();
if (!$form || (int) $form['is_active'] !== 1) {
    header('Location: ' . BASE_URL . '/public/404.html');
    exit();
}
$fieldStmt = $pdo->prepare('SELECT * FROM form_fields WHERE form_id = :form_id AND is_active = 1 ORDER BY sort_order ASC, id ASC');
$fieldStmt->execute([':form_id' => $form['id']]);
$fields = $fieldStmt->fetchAll();
$availability = get_form_availability($pdo, $form);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (!$availability['is_open']) {
        $errors[] = $availability['reason'];
    }

    if ((int) $form['enable_captcha'] === 1) {
        $honeypot = post('website');
        if ($honeypot !== '') {
            $errors[] = 'Suspeita de spam detectada.';
        }
    }

    $validatedValues = [];
    foreach ($fields as $field) {
        if ($field['field_type'] === 'file') {
            $fileInfo = $_FILES['field_' . $field['id']] ?? null;
            if ((int) $field['is_required'] === 1 && (!$fileInfo || $fileInfo['error'] === 4)) {
                $errors[] = 'O campo ' . $field['label'] . ' é obrigatório.';
                continue;
            }
            if ($fileInfo && $fileInfo['error'] === 0) {
                if ($fileInfo['size'] > MAX_UPLOAD_SIZE) {
                    $errors[] = 'Arquivo maior do que o permitido em ' . $field['label'] . '.';
                    continue;
                }
                $mime = mime_content_type($fileInfo['tmp_name']);
                if (!in_array($mime, ALLOWED_FILE_TYPES, true)) {
                    $errors[] = 'Tipo de arquivo inválido em ' . $field['label'] . '.';
                    continue;
                }
                $filename = uniqid('upload_', true) . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileInfo['name']);
                move_uploaded_file($fileInfo['tmp_name'], UPLOAD_DIR . $filename);
                $validatedValues[$field['id']] = $filename;
            }
            continue;
        }

        $incoming = $field['field_type'] === 'checkbox'
            ? ($_POST['field_' . $field['id']] ?? [])
            : ($_POST['field_' . $field['id']] ?? '');

        $error = validate_field_value($field, $incoming);
        if ($error) {
            $errors[] = $error;
        }
        $validatedValues[$field['id']] = sanitize_input($incoming);
    }

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            $submit = $pdo->prepare('INSERT INTO submissions (form_id, ip_address, user_agent, created_at, updated_at, status) VALUES (:form_id, :ip_address, :user_agent, NOW(), NOW(), 1)');
            $submit->execute([
                ':form_id' => $form['id'],
                ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            ]);
            $submissionId = $pdo->lastInsertId();
            foreach ($validatedValues as $fieldId => $value) {
                save_submission_value($pdo, $submissionId, $fieldId, $value);
            }
            audit_log($pdo, 'create', 'submission', $submissionId, 'Recebeu uma nova resposta pública.', null, ['form_id' => $form['id'], 'slug' => $form['slug']], null);
            $pdo->commit();
            send_notification_email_if_enabled($form, $submissionId);
            flash('success', $form['success_message'] ?: 'Formulário enviado com sucesso!');
            redirect('/public/form.php?slug=' . urlencode($slug));
        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'Erro ao salvar o formulário: ' . $e->getMessage();
        }
    }
}

$title = $form['title'];
require_once __DIR__ . '/../includes/header.php';
?>
<div class="public-header">
    <div>
    <?php if (!empty($form['cover_image'])): ?><img class="form-cover form-cover-lg" src="<?= e(form_cover_url($form['cover_image'])) ?>" alt="Capa do formulário <?= e($form['title']) ?>"><?php endif; ?>
        <h1 class="page-title"><?= e($form['title']) ?></h1>
        <p class="muted"><?= e($form['description']) ?></p>
    </div>
    <a class="btn btn-light" href="<?= BASE_URL ?>/public/index.php">Voltar</a>
</div>
<div class="card">
    <div class="meta-list">
        <div class="meta-row"><span>Status</span><span><?= render_availability_badge($availability['status']) ?></span></div>
        <div class="meta-row"><span>Janela de publicação</span><span><?= e(format_datetime_br($form['available_from'])) ?> até <?= e(format_datetime_br($form['available_until'])) ?></span></div>
        <div class="meta-row"><span>Limite de respostas</span><span><?= $form['max_responses'] ? (int) $form['max_responses'] : 'Ilimitado' ?></span></div>
    </div>
    <?php if (!$availability['is_open']): ?>
        <div class="alert alert-warning"><?= e($availability['reason']) ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="alert alert-danger"><?= e(implode(' ', $errors)) ?></div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" class="public-form">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <?php if ((int) $form['enable_captcha'] === 1): ?>
            <div style="display:none"><input type="text" name="website" value=""></div>
        <?php endif; ?>
        <div class="grid grid-2">
        <?php foreach ($fields as $field): ?>
            <?php $options = json_decode((string)$field['options_json'], true) ?: []; $fieldName = 'field_' . $field['id']; $saved = $_POST[$fieldName] ?? $field['default_value']; ?>
            <div class="form-group" style="width: <?= (int) $field['width'] ?>%">
                <label><?= e($field['label']) ?> <?= $field['is_required'] ? '*' : '' ?></label>
                <?php if ($field['field_type'] === 'textarea'): ?>
                    <textarea class="<?= e($field['css_class']) ?>" name="<?= e($fieldName) ?>" placeholder="<?= e($field['placeholder']) ?>" data-required="<?= (int) $field['is_required'] ?>" data-label="<?= e($field['label']) ?>" <?= !$availability['is_open'] ? 'disabled' : '' ?>><?= e($saved) ?></textarea>
                <?php elseif ($field['field_type'] === 'select'): ?>
                    <select class="<?= e($field['css_class']) ?>" name="<?= e($fieldName) ?>" data-required="<?= (int) $field['is_required'] ?>" data-label="<?= e($field['label']) ?>" <?= !$availability['is_open'] ? 'disabled' : '' ?>>
                        <option value="">Selecione</option>
                        <?php foreach ($options as $option): ?>
                            <option value="<?= e($option['value']) ?>" <?= (string)$saved === (string)$option['value'] ? 'selected' : '' ?>><?= e($option['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php elseif ($field['field_type'] === 'radio'): ?>
                    <?php foreach ($options as $option): ?>
                        <label><input type="radio" name="<?= e($fieldName) ?>" value="<?= e($option['value']) ?>" <?= (string)$saved === (string)$option['value'] ? 'checked' : '' ?> <?= !$availability['is_open'] ? 'disabled' : '' ?>> <?= e($option['label']) ?></label><br>
                    <?php endforeach; ?>
                <?php elseif ($field['field_type'] === 'checkbox'): ?>
                    <?php $savedValues = is_array($saved) ? $saved : []; foreach ($options as $option): ?>
                        <label><input type="checkbox" name="<?= e($fieldName) ?>[]" value="<?= e($option['value']) ?>" <?= in_array($option['value'], $savedValues, true) ? 'checked' : '' ?> <?= !$availability['is_open'] ? 'disabled' : '' ?>> <?= e($option['label']) ?></label><br>
                    <?php endforeach; ?>
                <?php elseif ($field['field_type'] === 'file'): ?>
                    <input type="file" class="<?= e($field['css_class']) ?>" name="<?= e($fieldName) ?>" <?= !$availability['is_open'] ? 'disabled' : '' ?>>
                <?php else: ?>
                    <input type="<?= e($field['field_type']) ?>" class="<?= e($field['css_class']) ?>" name="<?= e($fieldName) ?>" value="<?= e($saved) ?>" placeholder="<?= e($field['placeholder']) ?>" data-required="<?= (int) $field['is_required'] ?>" data-label="<?= e($field['label']) ?>" <?= !$availability['is_open'] ? 'disabled' : '' ?>>
                <?php endif; ?>
                <?php if ($field['mask']): ?><div class="small">Máscara sugerida: <?= e($field['mask']) ?></div><?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>
        <button class="btn <?= !$availability['is_open'] ? 'btn-disabled' : '' ?>" type="submit" <?= !$availability['is_open'] ? 'disabled' : '' ?>>Enviar formulário</button>
    </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
