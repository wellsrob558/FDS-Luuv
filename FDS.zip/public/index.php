<?php
require_once __DIR__ . '/../config/config.php';
$forms = $pdo->query('SELECT f.*, (SELECT COUNT(*) FROM submissions s WHERE s.form_id = f.id) AS responses_count FROM forms f WHERE is_active = 1 ORDER BY created_at DESC')->fetchAll();
$title = 'Formulários públicos';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="public-header">
    <div>
        <h1 class="page-title">Formulários públicos</h1>
        <p class="muted">Acesse qualquer formulário publicado.</p>
    </div>
    <?php if (is_logged_in()): ?><a class="btn btn-light" href="<?= admin_url('/dashboard.php') ?>">Painel</a><?php endif; ?>
</div>
<div class="grid">
    <?php foreach ($forms as $form): ?>
        <?php $availability = get_form_availability($pdo, $form); ?>
        <div class="card form-card">
            <?php if (!empty($form['cover_image'])): ?><img class="form-cover" src="<?= e(form_cover_url($form['cover_image'])) ?>" alt="Capa do formulário <?= e($form['title']) ?>"><?php endif; ?>
            <h3><?= e($form['title']) ?></h3>
            <p class="muted"><?= e($form['description']) ?></p>
            <div class="meta-list">
                <div class="meta-row"><span>Status</span><span><?= render_availability_badge($availability['status']) ?></span></div>
                <div class="meta-row"><span>Janela</span><span><?= e(format_datetime_br($form['available_from'])) ?> até <?= e(format_datetime_br($form['available_until'])) ?></span></div>
            </div>
            <p class="small"><?= e($availability['reason']) ?></p>
            <div class="actions">
                <?php if ($availability['is_open']): ?>
                    <a class="btn" href="<?= e(public_form_url($form['slug'])) ?>">Abrir formulário</a>
                <?php else: ?>
                    <a class="btn btn-disabled" href="<?= e(public_form_url($form['slug'])) ?>">Ver detalhes</a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
