<?php
require_once __DIR__ . '/../config/config.php';
$forms = $pdo->query('SELECT * FROM forms WHERE is_active = 1 ORDER BY created_at DESC')->fetchAll();
$title = 'Formulários públicos';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="public-header">
    <div>
        <h1 class="page-title">Formulários públicos</h1>
        <p class="muted">Acesse qualquer formulário publicado.</p>
    </div>
    <?php if (is_logged_in()): ?><a class="btn btn-light" href="<?= admin_url('/dashboard.php') ?>">Painel</a><?php endif; ?>
</div>
<div class="grid">
    <?php foreach ($forms as $form): ?>
        <div class="card">
            <h3><?= e($form['title']) ?></h3>
            <p class="muted"><?= e($form['description']) ?></p>
            <div class="actions">
                <a class="btn" href="<?= e(public_form_url($form['slug'])) ?>">Abrir formulário</a>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
