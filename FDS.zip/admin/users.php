<?php
include('../config/database.php');
include('../includes/audit.php');
session_start();
$user_id = $_SESSION['user_id'] ?? 1;

if(isset($_POST['save'])){
    $id=$_POST['id'] ?? '';
    $name=$_POST['name'];
    $email=$_POST['email'];

    if($id){
        $stmt=$conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
        $stmt->bind_param("ssi",$name,$email,$id);
        audit($conn,$user_id,"edit user ".$id);
    }else{
        $pass=password_hash($_POST['password'],PASSWORD_DEFAULT);
        $stmt=$conn->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
        $stmt->bind_param("sss",$name,$email,$pass);
        audit($conn,$user_id,"create user ".$email);
    }
    $stmt->execute();
}

if(isset($_GET['delete'])){
    $id=$_GET['delete'];
    $stmt=$conn->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();
    audit($conn,$user_id,"delete user ".$id);
}

$res=$conn->query("SELECT * FROM users");
?>

<h2>Usuários</h2>

<form method="POST">
<input type="hidden" name="id" value="<?= $_GET['edit'] ?? '' ?>">
<input name="name" placeholder="Nome">
<input name="email" placeholder="Email">
<input name="password" placeholder="Senha">
<button name="save">Salvar</button>
</form>

<hr>

<?php while($u=$res->fetch_assoc()){ ?>
<div>
<?= $u['name'] ?> - <?= $u['email'] ?>
<a href="?edit=<?= $u['id'] ?>">Editar</a>
<a href="?delete=<?= $u['id'] ?>">Excluir</a>
</div>
<?php } ?>
