<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin']);

$roles = get_role_options();
$id = (int) get('id');
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();
if (!$user) {
    exit('Usuário não encontrado.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = post('name');
    $email = post('email');
    $role = post('role', $user['role']);
    $status = is_checked('status');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '') {
        flash('error', 'Preencha nome e e-mail.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('error', 'Informe um e-mail válido.');
    } elseif (!isset($roles[$role])) {
        flash('error', 'Perfil inválido.');
    } elseif ((int) $user['status'] === 1 && $user['role'] === 'super_admin' && (($status !== 1) || $role !== 'super_admin') && count_active_super_admins($pdo) <= 1) {
        flash('error', 'Não é possível desativar ou rebaixar o último super admin ativo.');
    } else {
        $before = $user;
        try {
            $sql = 'UPDATE users SET name = :name, email = :email, role = :role, status = :status, updated_at = NOW()';
            $params = [
                ':name' => $name,
                ':email' => $email,
                ':role' => $role,
                ':status' => $status,
                ':id' => $id,
            ];
            if ($password !== '') {
                $sql .= ', password_hash = :password_hash';
                $params[':password_hash'] = password_hash($password, PASSWORD_DEFAULT);
            }
            $sql .= ' WHERE id = :id';
            $pdo->prepare($sql)->execute($params);

            $stmt->execute([':id' => $id]);
            $user = $stmt->fetch();
            refresh_session_user($pdo, $id);
            audit_log($pdo, 'update', 'user', $id, 'Atualizou um usuário.', $before, $user);
            flash('success', 'Usuário atualizado com sucesso.');
            redirect('/admin/users/index.php');
        } catch (Throwable $e) {
            flash('error', 'Erro ao atualizar usuário: ' . $e->getMessage());
        }
    }
}

$title = 'Editar usuário';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header"><div><h1 class="page-title">Editar usuário</h1><p class="muted">Ajuste permissões, status e senha quando necessário.</p></div></div>
<div class="card">
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <div class="grid grid-2">
            <div class="form-group"><label>Nome</label><input type="text" name="name" value="<?= e($user['name']) ?>" required></div>
            <div class="form-group"><label>E-mail</label><input type="email" name="email" value="<?= e($user['email']) ?>" required></div>
            <div class="form-group"><label>Perfil</label>
                <select name="role">
                    <?php foreach ($roles as $key => $label): ?>
                        <option value="<?= e($key) ?>" <?= $user['role'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Nova senha (opcional)</label><input type="password" name="password" placeholder="Preencha apenas se quiser trocar"></div>
        </div>
        <div class="form-group inline"><label><input type="checkbox" name="status" <?= $user['status'] ? 'checked' : '' ?>> Usuário ativo</label></div>
        <div class="actions">
            <button class="btn" type="submit">Salvar</button>
            <a class="btn btn-light" href="<?= admin_url('/users/index.php') ?>">Cancelar</a>
        </div>
    </form>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
