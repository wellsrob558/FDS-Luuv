<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin']);

$search = get('search');
$sql = 'SELECT * FROM users';
$params = [];
if ($search !== '') {
    $sql .= ' WHERE name LIKE :search OR email LIKE :search';
    $params[':search'] = '%' . $search . '%';
}
$sql .= ' ORDER BY created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$title = 'Usuários';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Usuários</h1>
        <p class="muted">Crie, edite e controle o acesso ao painel.</p>
    </div>
    <a class="btn" href="<?= admin_url('/users/create.php') ?>">Novo usuário</a>
</div>
<div class="card">
    <form class="search-bar" method="get">
        <input type="text" name="search" placeholder="Buscar por nome ou e-mail" value="<?= e($search) ?>">
        <button class="btn" type="submit">Buscar</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Perfil</th>
                    <th>Status</th>
                    <th>Criado em</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td>#<?= (int) $user['id'] ?></td>
                        <td>
                            <strong><?= e($user['name']) ?></strong><br>
                            <span class="small"><?= e($user['email']) ?></span>
                        </td>
                        <td><?= e(role_label($user['role'])) ?></td>
                        <td><?= render_status_badge($user['status']) ?></td>
                        <td><?= e(format_datetime_br($user['created_at'])) ?></td>
                        <td>
                            <div class="actions">
                                <a class="btn btn-light" href="<?= admin_url('/users/edit.php?id=' . $user['id']) ?>">Editar</a>
                                <?php if ((int) $user['id'] !== (int) current_user()['id']): ?>
                                    <a class="btn <?= $user['status'] ? 'btn-light' : 'btn-success' ?> js-confirm" data-confirm="Alterar status deste usuário?" href="<?= admin_url('/users/toggle.php?id=' . $user['id']) ?>"><?= $user['status'] ? 'Desativar' : 'Ativar' ?></a>
                                    <a class="btn btn-danger js-confirm" data-confirm="Excluir este usuário?" href="<?= admin_url('/users/delete.php?id=' . $user['id']) ?>">Excluir</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
