<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin']);

$roles = get_role_options();
$formValues = [
    'name' => '',
    'email' => '',
    'role' => 'editor',
    'status' => 1,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = post('name');
    $email = post('email');
    $role = post('role', 'editor');
    $status = is_checked('status');
    $password = $_POST['password'] ?? '';

    $formValues = compact('name', 'email', 'role', 'status');

    if ($name === '' || $email === '' || $password === '') {
        flash('error', 'Preencha nome, e-mail e senha.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('error', 'Informe um e-mail válido.');
    } elseif (!isset($roles[$role])) {
        flash('error', 'Perfil inválido.');
    } else {
        try {
            $stmt = $pdo->prepare('INSERT INTO users (name, email, password_hash, role, status, created_at, updated_at) VALUES (:name, :email, :password_hash, :role, :status, NOW(), NOW())');
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
                ':role' => $role,
                ':status' => $status,
            ]);
            $userId = $pdo->lastInsertId();
            audit_log($pdo, 'create', 'user', $userId, 'Criou um usuário.', null, ['id' => $userId, 'name' => $name, 'email' => $email, 'role' => $role, 'status' => $status]);
            flash('success', 'Usuário criado com sucesso.');
            redirect('/admin/users/index.php');
        } catch (Throwable $e) {
            flash('error', 'Erro ao criar usuário: ' . $e->getMessage());
        }
    }
}

$title = 'Novo usuário';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header"><div><h1 class="page-title">Novo usuário</h1><p class="muted">Cadastre um novo acesso ao painel.</p></div></div>
<div class="card">
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <div class="grid grid-2">
            <div class="form-group"><label>Nome</label><input type="text" name="name" value="<?= e($formValues['name']) ?>" required></div>
            <div class="form-group"><label>E-mail</label><input type="email" name="email" value="<?= e($formValues['email']) ?>" required></div>
            <div class="form-group"><label>Perfil</label>
                <select name="role">
                    <?php foreach ($roles as $key => $label): ?>
                        <option value="<?= e($key) ?>" <?= $formValues['role'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Senha inicial</label><input type="password" name="password" required></div>
        </div>
        <div class="form-group inline"><label><input type="checkbox" name="status" <?= $formValues['status'] ? 'checked' : '' ?>> Usuário ativo</label></div>
        <div class="actions">
            <button class="btn" type="submit">Salvar</button>
            <a class="btn btn-light" href="<?= admin_url('/users/index.php') ?>">Cancelar</a>
        </div>
    </form>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
