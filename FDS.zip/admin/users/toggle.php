<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin']);

$id = (int) get('id');
if ($id === (int) current_user()['id']) {
    flash('error', 'Você não pode desativar sua própria conta por aqui.');
    redirect('/admin/users/index.php');
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();
if (!$user) {
    flash('error', 'Usuário não encontrado.');
    redirect('/admin/users/index.php');
}
if ((int) $user['status'] === 1 && $user['role'] === 'super_admin' && count_active_super_admins($pdo) <= 1) {
    flash('error', 'Não é possível desativar o último super admin ativo.');
    redirect('/admin/users/index.php');
}

$before = $user;
$pdo->prepare('UPDATE users SET status = IF(status = 1, 0, 1), updated_at = NOW() WHERE id = :id')->execute([':id' => $id]);
$stmt->execute([':id' => $id]);
$after = $stmt->fetch();
audit_log($pdo, 'toggle_status', 'user', $id, 'Alterou o status de um usuário.', $before, $after);
flash('success', 'Status do usuário atualizado.');
redirect('/admin/users/index.php');
