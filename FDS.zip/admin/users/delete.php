<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin']);

$id = (int) get('id');
if ($id === (int) current_user()['id']) {
    flash('error', 'Você não pode excluir sua própria conta por aqui.');
    redirect('/admin/users/index.php');
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();
if (!$user) {
    flash('error', 'Usuário não encontrado.');
    redirect('/admin/users/index.php');
}
if ((int) $user['status'] === 1 && $user['role'] === 'super_admin' && count_active_super_admins($pdo) <= 1) {
    flash('error', 'Não é possível excluir o último super admin ativo.');
    redirect('/admin/users/index.php');
}

$pdo->prepare('DELETE FROM users WHERE id = :id')->execute([':id' => $id]);
audit_log($pdo, 'delete', 'user', $id, 'Excluiu um usuário.', $user, null);
flash('success', 'Usuário excluído.');
redirect('/admin/users/index.php');
