<?php
require_once __DIR__ . '/../config/config.php';
require_login();

$formCount = (int) $pdo->query('SELECT COUNT(*) FROM forms')->fetchColumn();
$activeFormCount = (int) $pdo->query('SELECT COUNT(*) FROM forms WHERE is_active = 1')->fetchColumn();
$responseCount = (int) $pdo->query('SELECT COUNT(*) FROM submissions')->fetchColumn();
$userCount = (int) $pdo->query('SELECT COUNT(*) FROM users WHERE status = 1')->fetchColumn();

$formsForAvailability = $pdo->query('SELECT f.*, (SELECT COUNT(*) FROM submissions s WHERE s.form_id = f.id) AS responses_count FROM forms f')->fetchAll();
$openFormsCount = 0;
foreach ($formsForAvailability as $availabilityForm) {
    $availability = get_form_availability($pdo, $availabilityForm);
    if ($availability['is_open']) {
        $openFormsCount++;
    }
}

$recentForms = $pdo->query('SELECT * FROM forms ORDER BY created_at DESC LIMIT 5')->fetchAll();
$recentResponses = $pdo->query('SELECT s.id, s.created_at, f.title FROM submissions s INNER JOIN forms f ON f.id = s.form_id ORDER BY s.created_at DESC LIMIT 5')->fetchAll();
$recentLogs = $pdo->query('SELECT al.*, u.name AS user_name FROM audit_logs al LEFT JOIN users u ON u.id = al.user_id ORDER BY al.created_at DESC LIMIT 8')->fetchAll();

$days = [];
for ($i = 6; $i >= 0; $i--) {
    $key = date('Y-m-d', strtotime('-' . $i . ' days'));
    $days[$key] = 0;
}
$submissionSeriesStmt = $pdo->query("SELECT DATE(created_at) AS day, COUNT(*) AS total FROM submissions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY DATE(created_at) ORDER BY day ASC");
foreach ($submissionSeriesStmt->fetchAll() as $row) {
    if (isset($days[$row['day']])) {
        $days[$row['day']] = (int) $row['total'];
    }
}

$formStatusChart = [
    'type' => 'doughnut',
    'data' => [
        'labels' => ['Ativos', 'Inativos'],
        'datasets' => [[
            'data' => [$activeFormCount, max(0, $formCount - $activeFormCount)],
        ]],
    ],
    'options' => ['responsive' => true, 'plugins' => ['legend' => ['position' => 'bottom']]],
];

$submissionChart = [
    'type' => 'bar',
    'data' => [
        'labels' => array_map(fn($day) => date('d/m', strtotime($day)), array_keys($days)),
        'datasets' => [[
            'label' => 'Respostas por dia',
            'data' => array_values($days),
        ]],
    ],
    'options' => ['responsive' => true, 'plugins' => ['legend' => ['display' => false]]],
];

$topFormsRows = $pdo->query('SELECT f.title, COUNT(s.id) AS total FROM forms f LEFT JOIN submissions s ON s.form_id = f.id GROUP BY f.id, f.title ORDER BY total DESC, f.title ASC LIMIT 5')->fetchAll();
$topFormsChart = [
    'type' => 'bar',
    'data' => [
        'labels' => array_map(fn($row) => $row['title'], $topFormsRows),
        'datasets' => [[
            'label' => 'Respostas',
            'data' => array_map(fn($row) => (int) $row['total'], $topFormsRows),
        ]],
    ],
    'options' => ['responsive' => true, 'indexAxis' => 'y', 'plugins' => ['legend' => ['display' => false]]],
];

$title = 'Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Dashboard</h1>
        <p class="muted">Resumo do sistema de formulários dinâmicos com indicadores e gráficos.</p>
    </div>
    <a class="btn" href="<?= admin_url('/forms/create.php') ?>">Novo formulário</a>
</div>
<div class="stats">
    <div class="card stat-card"><span class="muted">Total de formulários</span><strong><?= $formCount ?></strong></div>
    <div class="card stat-card"><span class="muted">Formulários ativos</span><strong><?= $activeFormCount ?></strong></div>
    <div class="card stat-card"><span class="muted">Formulários abertos agora</span><strong><?= $openFormsCount ?></strong></div>
    <div class="card stat-card"><span class="muted">Respostas recebidas</span><strong><?= $responseCount ?></strong></div>
</div>
<div class="grid grid-2">
    <div class="card chart-card">
        <h3>Respostas dos últimos 7 dias</h3>
        <canvas data-chart='<?= e(json_encode($submissionChart, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>'></canvas>
    </div>
    <div class="card chart-card">
        <h3>Status dos formulários</h3>
        <canvas data-chart='<?= e(json_encode($formStatusChart, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>'></canvas>
    </div>
</div>
<div class="grid grid-2">
    <div class="card chart-card">
        <h3>Top 5 formulários por respostas</h3>
        <canvas data-chart='<?= e(json_encode($topFormsChart, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>'></canvas>
    </div>
    <div class="card">
        <h3>Visão rápida</h3>
        <div class="meta-list">
            <div class="meta-row"><span>Usuários ativos</span><strong><?= $userCount ?></strong></div>
            <div class="meta-row"><span>Última atualização do painel</span><strong><?= e(date('d/m/Y H:i')) ?></strong></div>
            <div class="meta-row"><span>Formulários com limite configurado</span><strong><?= (int) $pdo->query('SELECT COUNT(*) FROM forms WHERE max_responses IS NOT NULL')->fetchColumn() ?></strong></div>
            <div class="meta-row"><span>Formulários com janela de publicação</span><strong><?= (int) $pdo->query('SELECT COUNT(*) FROM forms WHERE available_from IS NOT NULL OR available_until IS NOT NULL')->fetchColumn() ?></strong></div>
        </div>
    </div>
</div>
<div class="grid grid-2">
    <div class="card">
        <h3>Formulários recentes</h3>
        <?php if (!$recentForms): ?>
            <div class="empty-state">Nenhum formulário cadastrado.</div>
        <?php else: ?>
            <?php foreach ($recentForms as $recentForm): ?>
                <div class="meta-row">
                    <div>
                        <strong><?= e($recentForm['title']) ?></strong><br>
                        <span class="small"><?= e($recentForm['slug']) ?></span>
                    </div>
                    <span><?= e(format_datetime_br($recentForm['created_at'])) ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <div class="card">
        <h3>Respostas recentes</h3>
        <?php if (!$recentResponses): ?>
            <div class="empty-state">Nenhuma resposta recebida ainda.</div>
        <?php else: ?>
            <?php foreach ($recentResponses as $response): ?>
                <div class="meta-row">
                    <div>
                        <strong>#<?= (int) $response['id'] ?></strong><br>
                        <span class="small"><?= e($response['title']) ?></span>
                    </div>
                    <span><?= e(format_datetime_br($response['created_at'])) ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<div class="card">
    <div class="page-header">
        <div>
            <h3>Auditoria recente</h3>
            <p class="muted">Últimas ações registradas no sistema.</p>
        </div>
        <?php if (has_role(['super_admin', 'editor'])): ?>
            <a class="btn btn-light" href="<?= admin_url('/audit_logs.php') ?>">Ver tudo</a>
        <?php endif; ?>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Quando</th>
                    <th>Usuário</th>
                    <th>Ação</th>
                    <th>Entidade</th>
                    <th>Descrição</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentLogs as $log): ?>
                    <tr>
                        <td><?= e(format_datetime_br($log['created_at'])) ?></td>
                        <td><?= e($log['user_name'] ?: 'Público/Sistema') ?></td>
                        <td><?= e($log['action']) ?></td>
                        <td><?= e($log['entity_type']) ?><?= $log['entity_id'] ? ' #' . (int) $log['entity_id'] : '' ?></td>
                        <td><?= e($log['description']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
