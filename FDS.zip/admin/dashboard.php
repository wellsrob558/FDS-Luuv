<?php
require_once __DIR__ . '/../config/config.php';
require_login();

$formCount = $pdo->query('SELECT COUNT(*) FROM forms')->fetchColumn();
$activeFormCount = $pdo->query('SELECT COUNT(*) FROM forms WHERE is_active = 1')->fetchColumn();
$responseCount = $pdo->query('SELECT COUNT(*) FROM submissions')->fetchColumn();
$userCount = $pdo->query('SELECT COUNT(*) FROM users WHERE status = 1')->fetchColumn();

$recentForms = $pdo->query('SELECT * FROM forms ORDER BY created_at DESC LIMIT 5')->fetchAll();
$recentResponses = $pdo->query('SELECT s.id, s.created_at, f.title FROM submissions s INNER JOIN forms f ON f.id = s.form_id ORDER BY s.created_at DESC LIMIT 5')->fetchAll();

$title = 'Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Dashboard</h1>
        <p class="muted">Resumo do sistema de formulários dinâmicos.</p>
    </div>
    <a class="btn" href="<?= admin_url('/forms/create.php') ?>">Novo formulário</a>
</div>
<div class="stats">
    <div class="card stat-card"><span class="muted">Total de formulários</span><strong><?= (int) $formCount ?></strong></div>
    <div class="card stat-card"><span class="muted">Formulários ativos</span><strong><?= (int) $activeFormCount ?></strong></div>
    <div class="card stat-card"><span class="muted">Respostas recebidas</span><strong><?= (int) $responseCount ?></strong></div>
    <div class="card stat-card"><span class="muted">Usuários ativos</span><strong><?= (int) $userCount ?></strong></div>
</div>
<div class="grid grid-2">
    <div class="card">
        <h3>Formulários recentes</h3>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Título</th><th>Status</th><th>Criado em</th></tr></thead>
                <tbody>
                <?php foreach ($recentForms as $form): ?>
                    <tr>
                        <td><?= e($form['title']) ?></td>
                        <td><?= render_status_badge($form['is_active']) ?></td>
                        <td><?= e(date('d/m/Y H:i', strtotime($form['created_at']))) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card">
        <h3>Últimas respostas</h3>
        <div class="table-wrap">
            <table>
                <thead><tr><th>ID</th><th>Formulário</th><th>Data</th></tr></thead>
                <tbody>
                <?php foreach ($recentResponses as $response): ?>
                    <tr>
                        <td>#<?= (int) $response['id'] ?></td>
                        <td><?= e($response['title']) ?></td>
                        <td><?= e(date('d/m/Y H:i', strtotime($response['created_at']))) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
