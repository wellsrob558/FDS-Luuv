<?php
include('../config/database.php');
$form_id = $_GET['form_id'] ?? 1;

$res=$conn->query("SELECT * FROM fields WHERE form_id=$form_id ORDER BY position ASC");
?>

<h2>Campos (Form <?= $form_id ?>)</h2>

<ul id="fields">
<?php while($f=$res->fetch_assoc()){ ?>
<li data-id="<?= $f['id'] ?>"><?= $f['label'] ?></li>
<?php } ?>
</ul>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>

<script>
$("#fields").sortable({
 update:function(){
   let order=$(this).sortable('toArray',{attribute:'data-id'});
   $.post("save_order.php",{order:order});
 }
});
</script>
