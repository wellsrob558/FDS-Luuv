<?php
require_once __DIR__ . '/../config/config.php';
require_login();
require_role(['super_admin', 'editor']);

$search = get('search');
$action = get('action');
$entityType = get('entity_type');
$sql = 'SELECT al.*, u.name AS user_name FROM audit_logs al LEFT JOIN users u ON u.id = al.user_id WHERE 1=1';
$params = [];
if ($search !== '') {
    $sql .= ' AND (al.description LIKE :search OR u.name LIKE :search OR al.entity_type LIKE :search)';
    $params[':search'] = '%' . $search . '%';
}
if ($action !== '') {
    $sql .= ' AND al.action = :action';
    $params[':action'] = $action;
}
if ($entityType !== '') {
    $sql .= ' AND al.entity_type = :entity_type';
    $params[':entity_type'] = $entityType;
}
$sql .= ' ORDER BY al.created_at DESC LIMIT 100';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

$actions = $pdo->query('SELECT DISTINCT action FROM audit_logs ORDER BY action ASC')->fetchAll(PDO::FETCH_COLUMN);
$entities = $pdo->query('SELECT DISTINCT entity_type FROM audit_logs ORDER BY entity_type ASC')->fetchAll(PDO::FETCH_COLUMN);

$title = 'Auditoria';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Logs de auditoria</h1>
        <p class="muted">Histórico das ações administrativas e públicas registradas.</p>
    </div>
</div>
<div class="card">
    <form class="search-bar" method="get">
        <input type="text" name="search" placeholder="Buscar em descrição, usuário ou entidade" value="<?= e($search) ?>">
        <select name="action">
            <option value="">Todas as ações</option>
            <?php foreach ($actions as $actionOption): ?>
                <option value="<?= e($actionOption) ?>" <?= $action === $actionOption ? 'selected' : '' ?>><?= e($actionOption) ?></option>
            <?php endforeach; ?>
        </select>
        <select name="entity_type">
            <option value="">Todas as entidades</option>
            <?php foreach ($entities as $entityOption): ?>
                <option value="<?= e($entityOption) ?>" <?= $entityType === $entityOption ? 'selected' : '' ?>><?= e($entityOption) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn" type="submit">Filtrar</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Quando</th>
                    <th>Usuário</th>
                    <th>Ação</th>
                    <th>Entidade</th>
                    <th>Descrição</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?= e(format_datetime_br($log['created_at'])) ?></td>
                        <td><?= e($log['user_name'] ?: 'Público/Sistema') ?></td>
                        <td><?= e($log['action']) ?></td>
                        <td><?= e($log['entity_type']) ?><?= $log['entity_id'] ? ' #' . (int) $log['entity_id'] : '' ?></td>
                        <td>
                            <?= e($log['description']) ?>
                            <?php if ($log['old_values'] || $log['new_values']): ?>
                                <details>
                                    <summary>Detalhes</summary>
                                    <?php if ($log['old_values']): ?><pre><?= e($log['old_values']) ?></pre><?php endif; ?>
                                    <?php if ($log['new_values']): ?><pre><?= e($log['new_values']) ?></pre><?php endif; ?>
                                </details>
                            <?php endif; ?>
                        </td>
                        <td><?= e($log['ip_address']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
