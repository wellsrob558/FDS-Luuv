<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);

$id = (int) get('id');
$stmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $id]);
$form = $stmt->fetch();
if (!$form) {
    exit('Formulário não encontrado.');
}

$fieldStmt = $pdo->prepare('SELECT * FROM form_fields WHERE form_id = :form_id ORDER BY sort_order ASC, id ASC');
$fieldStmt->execute([':form_id' => $id]);
$fields = $fieldStmt->fetchAll();
$fields = array_map(function ($field) {
    $field['options_text'] = field_options_as_text($field['options_json']);
    return $field;
}, $fields);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $slug = post('slug') ?: slugify(post('title'));
    $pdo->beginTransaction();
    try {
        $update = $pdo->prepare('UPDATE forms SET title = :title, slug = :slug, description = :description, success_message = :success_message, notify_email = :notify_email, is_active = :is_active, enable_captcha = :enable_captcha, updated_at = NOW() WHERE id = :id');
        $update->execute([
            ':title' => post('title'),
            ':slug' => $slug,
            ':description' => post('description'),
            ':success_message' => post('success_message'),
            ':notify_email' => post('notify_email'),
            ':is_active' => is_checked('is_active'),
            ':enable_captcha' => is_checked('enable_captcha'),
            ':id' => $id,
        ]);

        $postedIds = [];
        foreach ($_POST['fields'] ?? [] as $field) {
            if (empty($field['name']) || empty($field['label']) || empty($field['field_type'])) {
                continue;
            }
            $fieldId = (int) ($field['id'] ?? 0);
            if ($fieldId > 0) {
                $postedIds[] = $fieldId;
                $updateField = $pdo->prepare('UPDATE form_fields SET field_type = :field_type, name = :name, label = :label, placeholder = :placeholder, is_required = :is_required, default_value = :default_value, mask = :mask, validation_rule = :validation_rule, css_class = :css_class, width = :width, options_json = :options_json, sort_order = :sort_order, is_active = :is_active, updated_at = NOW() WHERE id = :id AND form_id = :form_id');
                $updateField->execute([
                    ':field_type' => sanitize_input($field['field_type']),
                    ':name' => sanitize_input($field['name']),
                    ':label' => sanitize_input($field['label']),
                    ':placeholder' => sanitize_input($field['placeholder'] ?? ''),
                    ':is_required' => !empty($field['is_required']) ? 1 : 0,
                    ':default_value' => sanitize_input($field['default_value'] ?? ''),
                    ':mask' => sanitize_input($field['mask'] ?? ''),
                    ':validation_rule' => trim($field['validation_rule'] ?? ''),
                    ':css_class' => sanitize_input($field['css_class'] ?? ''),
                    ':width' => (int) ($field['width'] ?? 100),
                    ':options_json' => parse_options($field['options_text'] ?? ''),
                    ':sort_order' => (int) ($field['sort_order'] ?? 0),
                    ':is_active' => !empty($field['is_active']) ? 1 : 0,
                    ':id' => $fieldId,
                    ':form_id' => $id,
                ]);
            } else {
                $insert = $pdo->prepare('INSERT INTO form_fields (form_id, field_type, name, label, placeholder, is_required, default_value, mask, validation_rule, css_class, width, options_json, sort_order, is_active, created_at, updated_at)
                    VALUES (:form_id, :field_type, :name, :label, :placeholder, :is_required, :default_value, :mask, :validation_rule, :css_class, :width, :options_json, :sort_order, :is_active, NOW(), NOW())');
                $insert->execute([
                    ':form_id' => $id,
                    ':field_type' => sanitize_input($field['field_type']),
                    ':name' => sanitize_input($field['name']),
                    ':label' => sanitize_input($field['label']),
                    ':placeholder' => sanitize_input($field['placeholder'] ?? ''),
                    ':is_required' => !empty($field['is_required']) ? 1 : 0,
                    ':default_value' => sanitize_input($field['default_value'] ?? ''),
                    ':mask' => sanitize_input($field['mask'] ?? ''),
                    ':validation_rule' => trim($field['validation_rule'] ?? ''),
                    ':css_class' => sanitize_input($field['css_class'] ?? ''),
                    ':width' => (int) ($field['width'] ?? 100),
                    ':options_json' => parse_options($field['options_text'] ?? ''),
                    ':sort_order' => (int) ($field['sort_order'] ?? 0),
                    ':is_active' => !empty($field['is_active']) ? 1 : 0,
                ]);
            }
        }

        // Soft remove missing fields to preserve historical data.
        if ($postedIds) {
            $placeholders = implode(',', array_fill(0, count($postedIds), '?'));
            $params = array_merge([$id], $postedIds);
            $pdo->prepare("UPDATE form_fields SET is_active = 0, updated_at = NOW() WHERE form_id = ? AND id NOT IN ($placeholders)")->execute($params);
        } else {
            $pdo->prepare('UPDATE form_fields SET is_active = 0, updated_at = NOW() WHERE form_id = ?')->execute([$id]);
        }

        $pdo->commit();
        flash('success', 'Formulário atualizado com sucesso.');
        redirect('/admin/forms/index.php');
    } catch (Throwable $e) {
        $pdo->rollBack();
        flash('error', 'Erro ao atualizar formulário: ' . $e->getMessage());
    }
}

$title = 'Editar formulário';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header"><div><h1 class="page-title">Editar formulário</h1><p class="muted">Altere campos sem quebrar respostas antigas.</p></div></div>
<?php require __DIR__ . '/form_builder.php'; ?>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
