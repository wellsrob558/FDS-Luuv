<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $slug = post('slug') ?: slugify(post('title'));
    $availableFrom = datetime_local_to_db(post('available_from'));
    $availableUntil = datetime_local_to_db(post('available_until'));
    $maxResponses = positive_int_or_null(post('max_responses'));

    if ($scheduleError = validate_form_schedule($availableFrom, $availableUntil)) {
        flash('error', $scheduleError);
    } else {
        try {
            $coverImage = handle_form_cover_upload('cover_image');

            $formData = [
                ':title' => post('title'),
                ':slug' => $slug,
                ':description' => post('description'),
                ':success_message' => post('success_message'),
                ':notify_email' => post('notify_email'),
                ':is_active' => is_checked('is_active'),
                ':enable_captcha' => is_checked('enable_captcha'),
                ':cover_image' => $coverImage,
                ':max_responses' => $maxResponses,
                ':available_from' => $availableFrom,
                ':available_until' => $availableUntil,
            ];

            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare('INSERT INTO forms (title, slug, description, success_message, notify_email, is_active, enable_captcha, cover_image, max_responses, available_from, available_until, created_at, updated_at)
                    VALUES (:title, :slug, :description, :success_message, :notify_email, :is_active, :enable_captcha, :cover_image, :max_responses, :available_from, :available_until, NOW(), NOW())');
                $stmt->execute($formData);
                $formId = $pdo->lastInsertId();

                foreach ($_POST['fields'] ?? [] as $position => $field) {
                    if (empty($field['name']) || empty($field['label']) || empty($field['field_type'])) {
                        continue;
                    }
                    $insert = $pdo->prepare('INSERT INTO form_fields (form_id, field_type, name, label, placeholder, is_required, default_value, mask, validation_rule, css_class, width, options_json, sort_order, is_active, created_at, updated_at)
                        VALUES (:form_id, :field_type, :name, :label, :placeholder, :is_required, :default_value, :mask, :validation_rule, :css_class, :width, :options_json, :sort_order, :is_active, NOW(), NOW())');
                    $insert->execute([
                        ':form_id' => $formId,
                        ':field_type' => sanitize_input($field['field_type']),
                        ':name' => sanitize_input($field['name']),
                        ':label' => sanitize_input($field['label']),
                        ':placeholder' => sanitize_input($field['placeholder'] ?? ''),
                        ':is_required' => !empty($field['is_required']) ? 1 : 0,
                        ':default_value' => sanitize_input($field['default_value'] ?? ''),
                        ':mask' => sanitize_input($field['mask'] ?? ''),
                        ':validation_rule' => trim($field['validation_rule'] ?? ''),
                        ':css_class' => sanitize_input($field['css_class'] ?? ''),
                        ':width' => (int) ($field['width'] ?? 100),
                        ':options_json' => parse_options($field['options_text'] ?? ''),
                        ':sort_order' => $position + 1,
                        ':is_active' => !empty($field['is_active']) ? 1 : 0,
                    ]);
                }

                audit_log($pdo, 'create', 'form', $formId, 'Criou um novo formulário.', null, fetch_form_snapshot($pdo, $formId));
                $pdo->commit();
                flash('success', 'Formulário criado com sucesso.');
                redirect('/admin/forms/index.php');
            } catch (Throwable $e) {
                $pdo->rollBack();
                if (!empty($coverImage)) {
                    remove_uploaded_file_if_exists(FORM_COVER_DIR . $coverImage);
                }
                flash('error', 'Erro ao criar formulário: ' . $e->getMessage());
            }
        } catch (Throwable $e) {
            flash('error', $e->getMessage());
        }
    }
}

$title = 'Criar formulário';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header"><div><h1 class="page-title">Novo formulário</h1><p class="muted">Monte o formulário sem programar.</p></div></div>
<?php require __DIR__ . '/form_builder.php'; ?>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
