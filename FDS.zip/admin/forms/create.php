<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);

$form = [
    'title' => '',
    'slug' => '',
    'description' => '',
    'success_message' => 'Formulário enviado com sucesso!',
    'notify_email' => '',
    'is_active' => 1,
    'enable_captcha' => 0,
];
$fields = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $titleInput = post('title');
    $slug = post('slug') ?: slugify($titleInput);
    $formData = [
        ':title' => $titleInput,
        ':slug' => $slug,
        ':description' => post('description'),
        ':success_message' => post('success_message'),
        ':notify_email' => post('notify_email'),
        ':is_active' => is_checked('is_active'),
        ':enable_captcha' => is_checked('enable_captcha'),
    ];

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('INSERT INTO forms (title, slug, description, success_message, notify_email, is_active, enable_captcha, created_at, updated_at)
            VALUES (:title, :slug, :description, :success_message, :notify_email, :is_active, :enable_captcha, NOW(), NOW())');
        $stmt->execute($formData);
        $formId = $pdo->lastInsertId();

        foreach ($_POST['fields'] ?? [] as $field) {
            if (empty($field['name']) || empty($field['label']) || empty($field['field_type'])) {
                continue;
            }
            $insert = $pdo->prepare('INSERT INTO form_fields (form_id, field_type, name, label, placeholder, is_required, default_value, mask, validation_rule, css_class, width, options_json, sort_order, is_active, created_at, updated_at)
                VALUES (:form_id, :field_type, :name, :label, :placeholder, :is_required, :default_value, :mask, :validation_rule, :css_class, :width, :options_json, :sort_order, :is_active, NOW(), NOW())');
            $insert->execute([
                ':form_id' => $formId,
                ':field_type' => sanitize_input($field['field_type']),
                ':name' => sanitize_input($field['name']),
                ':label' => sanitize_input($field['label']),
                ':placeholder' => sanitize_input($field['placeholder'] ?? ''),
                ':is_required' => !empty($field['is_required']) ? 1 : 0,
                ':default_value' => sanitize_input($field['default_value'] ?? ''),
                ':mask' => sanitize_input($field['mask'] ?? ''),
                ':validation_rule' => trim($field['validation_rule'] ?? ''),
                ':css_class' => sanitize_input($field['css_class'] ?? ''),
                ':width' => (int) ($field['width'] ?? 100),
                ':options_json' => parse_options($field['options_text'] ?? ''),
                ':sort_order' => (int) ($field['sort_order'] ?? 0),
                ':is_active' => !empty($field['is_active']) ? 1 : 0,
            ]);
        }

        $pdo->commit();
        flash('success', 'Formulário criado com sucesso.');
        redirect('/admin/forms/index.php');
    } catch (Throwable $e) {
        $pdo->rollBack();
        flash('error', 'Erro ao criar formulário: ' . $e->getMessage());
    }
}

$title = 'Criar formulário';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header"><div><h1 class="page-title">Novo formulário</h1><p class="muted">Monte o formulário sem programar.</p></div></div>
<?php require __DIR__ . '/form_builder.php'; ?>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
