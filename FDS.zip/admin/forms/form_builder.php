<?php
$fieldTypes = get_field_types();
$fields = $fields ?? [];
?>
<script>
window.formFieldTypes = <?= json_encode($fieldTypes, JSON_UNESCAPED_UNICODE) ?>;
</script>
<form method="post" id="formBuilder" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <div class="grid grid-2">
        <div class="card">
            <h3>Configurações do formulário</h3>
            <div class="form-group">
                <label>Título</label>
                <input type="text" id="title" name="title" required value="<?= e($form['title'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Slug / URL amigável</label>
                <input type="text" name="slug" value="<?= e($form['slug'] ?? '') ?>" placeholder="gerado automaticamente se vazio">
            </div>
            <div class="form-group">
                <label>Descrição</label>
                <textarea id="description" name="description"><?= e($form['description'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label>Mensagem de sucesso</label>
                <textarea name="success_message"><?= e($form['success_message'] ?? 'Formulário enviado com sucesso!') ?></textarea>
            </div>
            <div class="form-group">
                <label>E-mail para notificação</label>
                <input type="email" name="notify_email" value="<?= e($form['notify_email'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Imagem de capa</label>
                <input type="file" name="cover_image" accept="image/jpeg,image/png,image/webp">
                <div class="small">Formatos aceitos: JPG, PNG ou WEBP. Máximo de <?= (int) (MAX_UPLOAD_SIZE / 1024 / 1024) ?> MB.</div>
                <?php if (!empty($form['cover_image'])): ?>
                    <div class="cover-upload-preview">
                        <img src="<?= e(form_cover_url($form['cover_image'])) ?>" alt="Capa atual do formulário">
                        <label class="inline"><input type="checkbox" name="remove_cover_image"> Remover capa atual</label>
                    </div>
                <?php endif; ?>
            </div>
            <div class="grid grid-2">
                <div class="form-group">
                    <label>Limite de respostas</label>
                    <input type="number" min="1" name="max_responses" value="<?= e($form['max_responses'] ?? '') ?>" placeholder="deixe vazio para ilimitado">
                </div>
                <div class="form-group">
                    <label>Abre em</label>
                    <input type="datetime-local" name="available_from" value="<?= e(db_datetime_to_local($form['available_from'] ?? '')) ?>">
                </div>
                <div class="form-group">
                    <label>Encerra em</label>
                    <input type="datetime-local" name="available_until" value="<?= e(db_datetime_to_local($form['available_until'] ?? '')) ?>">
                </div>
            </div>
            <div class="grid grid-2">
                <div class="form-group inline"><label><input type="checkbox" name="is_active" <?= !isset($form['is_active']) || $form['is_active'] ? 'checked' : '' ?>> Formulário ativo</label></div>
                <div class="form-group inline"><label><input type="checkbox" name="enable_captcha" <?= !empty($form['enable_captcha']) ? 'checked' : '' ?>> Anti-spam simples</label></div>
            </div>
        </div>
        <div class="card">
            <h3>Preview em tempo real</h3>
            <div class="preview-box" id="livePreview" data-cover="<?= e(!empty($form['cover_image']) ? form_cover_url($form['cover_image']) : '') ?>"></div>
        </div>
    </div>
    <div class="card">
        <div class="page-header">
            <div>
                <h3>Campos dinâmicos</h3>
                <p class="muted">Arraste para reordenar, personalize e visualize na hora.</p>
            </div>
            <button type="button" class="btn" id="addField">Adicionar campo</button>
        </div>
        <div class="helper-text">Use o botão “Arrastar” em cada bloco para ordenar os campos visualmente.</div>
        <div id="fieldsContainer">
            <?php foreach ($fields as $index => $field): ?>
                <div class="field-builder-item">
                    <div class="field-builder-top">
                        <span class="drag-handle" title="Arrastar para ordenar">↕ Arrastar</span>
                        <strong><?= e($field['label'] ?: 'Campo sem rótulo') ?></strong>
                    </div>
                    <div class="grid grid-3">
                        <div class="form-group">
                            <label>Tipo</label>
                            <select name="fields[<?= $index ?>][field_type]" class="field-type">
                                <?php foreach ($fieldTypes as $key => $label): ?>
                                    <option value="<?= e($key) ?>" <?= $field['field_type'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label>Nome interno</label><input type="text" name="fields[<?= $index ?>][name]" value="<?= e($field['name']) ?>" required></div>
                        <div class="form-group"><label>Rótulo</label><input type="text" name="fields[<?= $index ?>][label]" class="field-label" value="<?= e($field['label']) ?>" required></div>
                        <div class="form-group"><label>Placeholder</label><input type="text" name="fields[<?= $index ?>][placeholder]" class="field-placeholder" value="<?= e($field['placeholder']) ?>"></div>
                        <div class="form-group"><label>Valor padrão</label><input type="text" name="fields[<?= $index ?>][default_value]" value="<?= e($field['default_value']) ?>"></div>
                        <div class="form-group"><label>Máscara</label><input type="text" name="fields[<?= $index ?>][mask]" value="<?= e($field['mask']) ?>"></div>
                        <div class="form-group"><label>Validação Regex</label><input type="text" name="fields[<?= $index ?>][validation_rule]" value="<?= e($field['validation_rule']) ?>"></div>
                        <div class="form-group"><label>Classe CSS</label><input type="text" name="fields[<?= $index ?>][css_class]" class="field-class" value="<?= e($field['css_class']) ?>"></div>
                        <div class="form-group"><label>Largura (%)</label><input type="number" min="10" max="100" name="fields[<?= $index ?>][width]" class="field-width" value="<?= e($field['width']) ?>"></div>
                        <div class="form-group"><label>Ordem (automática)</label><input type="number" min="0" name="fields[<?= $index ?>][sort_order]" class="js-sort-order" value="<?= e($field['sort_order']) ?>" readonly></div>
                        <div class="form-group"><label>Opções (valor|rótulo)</label><textarea name="fields[<?= $index ?>][options_text]"><?= e($field['options_text']) ?></textarea></div>
                        <div class="form-group inline"><label><input type="checkbox" class="field-required" name="fields[<?= $index ?>][is_required]" <?= $field['is_required'] ? 'checked' : '' ?>> Obrigatório</label></div>
                        <div class="form-group inline"><label><input type="checkbox" name="fields[<?= $index ?>][is_active]" <?= $field['is_active'] ? 'checked' : '' ?>> Ativo</label></div>
                        <input type="hidden" name="fields[<?= $index ?>][id]" value="<?= e($field['id']) ?>">
                    </div>
                    <div class="actions"><button type="button" class="btn btn-light remove-field">Remover</button></div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="actions">
            <button class="btn" type="submit">Salvar formulário</button>
            <a class="btn btn-light" href="<?= admin_url('/forms/index.php') ?>">Cancelar</a>
        </div>
    </div>
</form>
<?php if (empty($fields)): ?>
<script>
$(function(){ $('#addField').trigger('click'); });
</script>
<?php endif; ?>
