<?php
$fieldTypes = get_field_types();
$fields = $fields ?? [];
?>
<script>
window.formFieldTypes = <?= json_encode($fieldTypes, JSON_UNESCAPED_UNICODE) ?>;
</script>
<form method="post" id="formBuilder">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <div class="grid grid-2">
        <div class="card">
            <h3>Configurações do formulário</h3>
            <div class="form-group">
                <label>Título</label>
                <input type="text" id="title" name="title" required value="<?= e($form['title'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Slug / URL amigável</label>
                <input type="text" name="slug" value="<?= e($form['slug'] ?? '') ?>" placeholder="gerado automaticamente se vazio">
            </div>
            <div class="form-group">
                <label>Descrição</label>
                <textarea id="description" name="description"><?= e($form['description'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label>Mensagem de sucesso</label>
                <textarea name="success_message"><?= e($form['success_message'] ?? 'Formulário enviado com sucesso!') ?></textarea>
            </div>
            <div class="form-group">
                <label>E-mail para notificação</label>
                <input type="email" name="notify_email" value="<?= e($form['notify_email'] ?? '') ?>">
            </div>
            <div class="grid grid-2">
                <div class="form-group inline"><label><input type="checkbox" name="is_active" <?= !isset($form['is_active']) || $form['is_active'] ? 'checked' : '' ?>> Formulário ativo</label></div>
                <div class="form-group inline"><label><input type="checkbox" name="enable_captcha" <?= !empty($form['enable_captcha']) ? 'checked' : '' ?>> Anti-spam simples</label></div>
            </div>
        </div>
        <div class="card">
            <h3>Preview em tempo real</h3>
            <div class="preview-box" id="livePreview"></div>
        </div>
    </div>
    <div class="card">
        <div class="page-header">
            <div>
                <h3>Campos dinâmicos</h3>
                <p class="muted">Adicione, reordene e personalize cada campo.</p>
            </div>
            <button type="button" class="btn" id="addField">Adicionar campo</button>
        </div>
        <div id="fieldsContainer">
            <?php foreach ($fields as $index => $field): ?>
                <div class="field-builder-item">
                    <div class="grid grid-3">
                        <div class="form-group">
                            <label>Tipo</label>
                            <select name="fields[<?= $index ?>][field_type]" class="field-type">
                                <?php foreach ($fieldTypes as $key => $label): ?>
                                    <option value="<?= e($key) ?>" <?= $field['field_type'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label>Nome interno</label><input type="text" name="fields[<?= $index ?>][name]" value="<?= e($field['name']) ?>" required></div>
                        <div class="form-group"><label>Rótulo</label><input type="text" name="fields[<?= $index ?>][label]" class="field-label" value="<?= e($field['label']) ?>" required></div>
                        <div class="form-group"><label>Placeholder</label><input type="text" name="fields[<?= $index ?>][placeholder]" class="field-placeholder" value="<?= e($field['placeholder']) ?>"></div>
                        <div class="form-group"><label>Valor padrão</label><input type="text" name="fields[<?= $index ?>][default_value]" value="<?= e($field['default_value']) ?>"></div>
                        <div class="form-group"><label>Máscara</label><input type="text" name="fields[<?= $index ?>][mask]" value="<?= e($field['mask']) ?>"></div>
                        <div class="form-group"><label>Validação Regex</label><input type="text" name="fields[<?= $index ?>][validation_rule]" value="<?= e($field['validation_rule']) ?>"></div>
                        <div class="form-group"><label>Classe CSS</label><input type="text" name="fields[<?= $index ?>][css_class]" class="field-class" value="<?= e($field['css_class']) ?>"></div>
                        <div class="form-group"><label>Largura (%)</label><input type="number" min="10" max="100" name="fields[<?= $index ?>][width]" class="field-width" value="<?= e($field['width']) ?>"></div>
                        <div class="form-group"><label>Ordem</label><input type="number" min="0" name="fields[<?= $index ?>][sort_order]" value="<?= e($field['sort_order']) ?>"></div>
                        <div class="form-group"><label>Opções (valor|rótulo)</label><textarea name="fields[<?= $index ?>][options_text]"><?= e($field['options_text']) ?></textarea></div>
                        <div class="form-group inline"><label><input type="checkbox" class="field-required" name="fields[<?= $index ?>][is_required]" <?= $field['is_required'] ? 'checked' : '' ?>> Obrigatório</label></div>
                        <div class="form-group inline"><label><input type="checkbox" name="fields[<?= $index ?>][is_active]" <?= $field['is_active'] ? 'checked' : '' ?>> Ativo</label></div>
                        <input type="hidden" name="fields[<?= $index ?>][id]" value="<?= e($field['id']) ?>">
                    </div>
                    <div class="actions"><button type="button" class="btn btn-light remove-field">Remover</button></div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="actions">
            <button class="btn" type="submit">Salvar formulário</button>
            <a class="btn btn-light" href="<?= admin_url('/forms/index.php') ?>">Cancelar</a>
        </div>
    </div>
</form>
<?php if (empty($fields)): ?>
<script>
$(function(){ $('#addField').trigger('click'); });
</script>
<?php endif; ?>
