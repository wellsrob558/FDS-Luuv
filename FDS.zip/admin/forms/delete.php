<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin']);

$id = (int) get('id');
$before = fetch_form_snapshot($pdo, $id);
$pdo->prepare('DELETE FROM forms WHERE id = :id')->execute([':id' => $id]);
if ($before) {
    audit_log($pdo, 'delete', 'form', $id, 'Excluiu um formulário.', $before, null);
}
flash('success', 'Formulário excluído.');
redirect('/admin/forms/index.php');
