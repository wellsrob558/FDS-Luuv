<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin']);
$id = (int) get('id');
$pdo->prepare('DELETE FROM forms WHERE id = :id')->execute([':id' => $id]);
flash('success', 'Formulário excluído.');
redirect('/admin/forms/index.php');
