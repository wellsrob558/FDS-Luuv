<?php
require_once __DIR__ . '/../../config/config.php';
require_login();

$search = get('search');
$sql = 'SELECT f.*, (SELECT COUNT(*) FROM submissions s WHERE s.form_id = f.id) AS responses_count FROM forms f';
$params = [];
if ($search !== '') {
    $sql .= ' WHERE f.title LIKE :search OR f.slug LIKE :search';
    $params[':search'] = '%' . $search . '%';
}
$sql .= ' ORDER BY f.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$forms = $stmt->fetchAll();

$title = 'Formulários';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Formulários</h1>
        <p class="muted">Gerencie, duplique e publique formulários dinâmicos.</p>
    </div>
    <a class="btn" href="<?= admin_url('/forms/create.php') ?>">Criar formulário</a>
</div>
<div class="card">
    <form class="search-bar" method="get">
        <input type="text" name="search" placeholder="Buscar por título ou slug" value="<?= e($search) ?>">
        <button class="btn" type="submit">Buscar</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Slug</th>
                    <th>Status</th>
                    <th>Respostas</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($forms as $form): ?>
                <tr>
                    <td>#<?= (int) $form['id'] ?></td>
                    <td>
                        <strong><?= e($form['title']) ?></strong><br>
                        <span class="small"><?= e($form['description']) ?></span>
                    </td>
                    <td><a href="<?= e(public_form_url($form['slug'])) ?>" target="_blank"><?= e($form['slug']) ?></a></td>
                    <td><?= render_status_badge($form['is_active']) ?></td>
                    <td><?= (int) $form['responses_count'] ?></td>
                    <td>
                        <div class="actions">
                            <a class="btn btn-light" href="<?= admin_url('/forms/edit.php?id=' . $form['id']) ?>">Editar</a>
                            <a class="btn btn-secondary" href="<?= admin_url('/forms/duplicate.php?id=' . $form['id']) ?>">Duplicar</a>
                            <a class="btn btn-success" href="<?= admin_url('/responses/index.php?form_id=' . $form['id']) ?>">Respostas</a>
                            <a class="btn <?= $form['is_active'] ? 'btn-light' : 'btn-success' ?> js-confirm" data-confirm="Alterar status deste formulário?" href="<?= admin_url('/forms/toggle.php?id=' . $form['id']) ?>"><?= $form['is_active'] ? 'Desativar' : 'Ativar' ?></a>
                            <a class="btn btn-danger js-confirm" data-confirm="Excluir este formulário?" href="<?= admin_url('/forms/delete.php?id=' . $form['id']) ?>">Excluir</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
