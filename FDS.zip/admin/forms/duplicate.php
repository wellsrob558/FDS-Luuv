<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);
$id = (int) get('id');

$formStmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id LIMIT 1');
$formStmt->execute([':id' => $id]);
$form = $formStmt->fetch();
if (!$form) {
    exit('Formulário não encontrado.');
}
$fieldStmt = $pdo->prepare('SELECT * FROM form_fields WHERE form_id = :id');
$fieldStmt->execute([':id' => $id]);
$fields = $fieldStmt->fetchAll();

$pdo->beginTransaction();
try {
    $slug = slugify($form['title'] . '-copia-' . time());
    $insertForm = $pdo->prepare('INSERT INTO forms (title, slug, description, success_message, notify_email, is_active, enable_captcha, created_at, updated_at)
        VALUES (:title, :slug, :description, :success_message, :notify_email, :is_active, :enable_captcha, NOW(), NOW())');
    $insertForm->execute([
        ':title' => $form['title'] . ' (Cópia)',
        ':slug' => $slug,
        ':description' => $form['description'],
        ':success_message' => $form['success_message'],
        ':notify_email' => $form['notify_email'],
        ':is_active' => 0,
        ':enable_captcha' => $form['enable_captcha'],
    ]);
    $newFormId = $pdo->lastInsertId();

    foreach ($fields as $field) {
        $insertField = $pdo->prepare('INSERT INTO form_fields (form_id, field_type, name, label, placeholder, is_required, default_value, mask, validation_rule, css_class, width, options_json, sort_order, is_active, created_at, updated_at)
            VALUES (:form_id, :field_type, :name, :label, :placeholder, :is_required, :default_value, :mask, :validation_rule, :css_class, :width, :options_json, :sort_order, :is_active, NOW(), NOW())');
        $insertField->execute([
            ':form_id' => $newFormId,
            ':field_type' => $field['field_type'],
            ':name' => $field['name'],
            ':label' => $field['label'],
            ':placeholder' => $field['placeholder'],
            ':is_required' => $field['is_required'],
            ':default_value' => $field['default_value'],
            ':mask' => $field['mask'],
            ':validation_rule' => $field['validation_rule'],
            ':css_class' => $field['css_class'],
            ':width' => $field['width'],
            ':options_json' => $field['options_json'],
            ':sort_order' => $field['sort_order'],
            ':is_active' => $field['is_active'],
        ]);
    }

    $pdo->commit();
    flash('success', 'Formulário duplicado com sucesso.');
} catch (Throwable $e) {
    $pdo->rollBack();
    flash('error', 'Erro ao duplicar formulário: ' . $e->getMessage());
}
redirect('/admin/forms/index.php');
