<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);
$id = (int) get('id');

$formStmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id LIMIT 1');
$formStmt->execute([':id' => $id]);
$form = $formStmt->fetch();
if (!$form) {
    exit('Formulário não encontrado.');
}
$fieldStmt = $pdo->prepare('SELECT * FROM form_fields WHERE form_id = :id ORDER BY sort_order ASC, id ASC');
$fieldStmt->execute([':id' => $id]);
$fields = $fieldStmt->fetchAll();

$pdo->beginTransaction();
try {
    $slug = slugify($form['title'] . '-copia-' . time());
    $copiedCoverImage = null;
    if (!empty($form['cover_image']) && is_file(FORM_COVER_DIR . $form['cover_image'])) {
        ensure_directory(FORM_COVER_DIR);
        $sourcePath = FORM_COVER_DIR . $form['cover_image'];
        $extension = pathinfo($sourcePath, PATHINFO_EXTENSION) ?: 'jpg';
        $copiedCoverImage = uniqid('cover_', true) . '.' . $extension;
        copy($sourcePath, FORM_COVER_DIR . $copiedCoverImage);
    }

    $insertForm = $pdo->prepare('INSERT INTO forms (title, slug, description, success_message, notify_email, is_active, enable_captcha, cover_image, max_responses, available_from, available_until, created_at, updated_at)
        VALUES (:title, :slug, :description, :success_message, :notify_email, :is_active, :enable_captcha, :cover_image, :max_responses, :available_from, :available_until, NOW(), NOW())');
    $insertForm->execute([
        ':title' => $form['title'] . ' (Cópia)',
        ':slug' => $slug,
        ':description' => $form['description'],
        ':success_message' => $form['success_message'],
        ':notify_email' => $form['notify_email'],
        ':is_active' => 0,
        ':enable_captcha' => $form['enable_captcha'],
        ':cover_image' => $copiedCoverImage,
        ':max_responses' => $form['max_responses'],
        ':available_from' => $form['available_from'],
        ':available_until' => $form['available_until'],
    ]);
    $newFormId = $pdo->lastInsertId();

    foreach ($fields as $field) {
        $insertField = $pdo->prepare('INSERT INTO form_fields (form_id, field_type, name, label, placeholder, is_required, default_value, mask, validation_rule, css_class, width, options_json, sort_order, is_active, created_at, updated_at)
            VALUES (:form_id, :field_type, :name, :label, :placeholder, :is_required, :default_value, :mask, :validation_rule, :css_class, :width, :options_json, :sort_order, :is_active, NOW(), NOW())');
        $insertField->execute([
            ':form_id' => $newFormId,
            ':field_type' => $field['field_type'],
            ':name' => $field['name'],
            ':label' => $field['label'],
            ':placeholder' => $field['placeholder'],
            ':is_required' => $field['is_required'],
            ':default_value' => $field['default_value'],
            ':mask' => $field['mask'],
            ':validation_rule' => $field['validation_rule'],
            ':css_class' => $field['css_class'],
            ':width' => $field['width'],
            ':options_json' => $field['options_json'],
            ':sort_order' => $field['sort_order'],
            ':is_active' => $field['is_active'],
        ]);
    }

    audit_log($pdo, 'duplicate', 'form', $newFormId, 'Duplicou um formulário.', ['source_form_id' => $id], fetch_form_snapshot($pdo, $newFormId));
    $pdo->commit();
    flash('success', 'Formulário duplicado com sucesso.');
} catch (Throwable $e) {
    $pdo->rollBack();
    if (!empty($copiedCoverImage)) {
        remove_uploaded_file_if_exists(FORM_COVER_DIR . $copiedCoverImage);
    }
    flash('error', 'Erro ao duplicar formulário: ' . $e->getMessage());
}
redirect('/admin/forms/index.php');
