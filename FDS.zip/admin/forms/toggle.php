<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);
$id = (int) get('id');
$pdo->prepare('UPDATE forms SET is_active = IF(is_active = 1, 0, 1), updated_at = NOW() WHERE id = :id')->execute([':id' => $id]);
flash('success', 'Status atualizado.');
redirect('/admin/forms/index.php');
