<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);
$id = (int) get('id');
$before = fetch_form_snapshot($pdo, $id);
$pdo->prepare('UPDATE forms SET is_active = IF(is_active = 1, 0, 1), updated_at = NOW() WHERE id = :id')->execute([':id' => $id]);
$after = fetch_form_snapshot($pdo, $id);
if ($after) {
    audit_log($pdo, 'toggle_status', 'form', $id, 'Alterou o status de um formulário.', $before, $after);
}
flash('success', 'Status atualizado.');
redirect('/admin/forms/index.php');
