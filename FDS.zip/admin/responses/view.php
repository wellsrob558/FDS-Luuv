<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
$formId = (int) get('form_id');
$id = (int) get('id');

$formStmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id');
$formStmt->execute([':id' => $formId]);
$form = $formStmt->fetch();

$responseStmt = $pdo->prepare('SELECT * FROM submissions WHERE id = :id AND form_id = :form_id');
$responseStmt->execute([':id' => $id, ':form_id' => $formId]);
$response = $responseStmt->fetch();
if (!$form || !$response) {
    exit('Registro não encontrado.');
}

$valueStmt = $pdo->prepare('SELECT ff.label, ff.field_type, COALESCE(sv.value_text, sv.value_json) AS value FROM submission_values sv INNER JOIN form_fields ff ON ff.id = sv.field_id WHERE sv.submission_id = :submission_id ORDER BY ff.sort_order ASC, ff.id ASC');
$valueStmt->execute([':submission_id' => $id]);
$values = $valueStmt->fetchAll();

$title = 'Visualizar resposta';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Resposta #<?= (int) $response['id'] ?></h1>
        <p class="muted">Formulário: <?= e($form['title']) ?></p>
    </div>
    <a class="btn btn-light" href="<?= admin_url('/responses/index.php?form_id=' . $formId) ?>">Voltar</a>
</div>
<div class="card">
    <div class="grid grid-2">
        <div><strong>Criado em:</strong> <?= e(date('d/m/Y H:i', strtotime($response['created_at']))) ?></div>
        <div><strong>IP:</strong> <?= e($response['ip_address']) ?></div>
    </div>
    <hr>
    <?php foreach ($values as $value): ?>
        <div class="form-group">
            <label><?= e($value['label']) ?></label>
            <div><?= nl2br(e(format_value_for_display($value['value']))) ?></div>
        </div>
    <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
