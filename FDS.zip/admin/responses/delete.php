<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);
$formId = (int) get('form_id');
$id = (int) get('id');
$pdo->prepare('DELETE FROM submissions WHERE id = :id AND form_id = :form_id')->execute([':id' => $id, ':form_id' => $formId]);
flash('success', 'Resposta excluída.');
redirect('/admin/responses/index.php?form_id=' . $formId);
