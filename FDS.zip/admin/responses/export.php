<?php
require_once __DIR__ . '/../../config/config.php';
require_login();

$formId = (int) get('form_id');
$type = get('type', 'csv');
$formStmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id');
$formStmt->execute([':id' => $formId]);
$form = $formStmt->fetch();
if (!$form) {
    exit('Formulário não encontrado.');
}

$fieldStmt = $pdo->prepare('SELECT * FROM form_fields WHERE form_id = :form_id ORDER BY sort_order ASC, id ASC');
$fieldStmt->execute([':form_id' => $formId]);
$fields = $fieldStmt->fetchAll();

$rowsStmt = $pdo->prepare('SELECT * FROM submissions WHERE form_id = :form_id ORDER BY created_at DESC');
$rowsStmt->execute([':form_id' => $formId]);
$responses = $rowsStmt->fetchAll();

$filename = slugify($form['title']) . '-' . date('Ymd-His');
if ($type === 'xls') {
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename . '.xls');
    echo "<table border='1'><tr><th>ID</th><th>Criado em</th>";
    foreach ($fields as $field) {
        echo '<th>' . e($field['label']) . '</th>';
    }
    echo '</tr>';
    foreach ($responses as $response) {
        echo '<tr><td>' . (int)$response['id'] . '</td><td>' . e($response['created_at']) . '</td>';
        $valueStmt = $pdo->prepare('SELECT field_id, COALESCE(value_text, value_json) AS value FROM submission_values WHERE submission_id = :submission_id');
        $valueStmt->execute([':submission_id' => $response['id']]);
        $values = [];
        foreach ($valueStmt->fetchAll() as $valueRow) {
            $values[$valueRow['field_id']] = format_value_for_display($valueRow['value']);
        }
        foreach ($fields as $field) {
            echo '<td>' . e($values[$field['id']] ?? '') . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
    exit;
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename . '.csv');
$output = fopen('php://output', 'w');
fputcsv($output, array_merge(['ID', 'Criado em'], array_map(fn($field) => $field['label'], $fields)), ';');
foreach ($responses as $response) {
    $valueStmt = $pdo->prepare('SELECT field_id, COALESCE(value_text, value_json) AS value FROM submission_values WHERE submission_id = :submission_id');
    $valueStmt->execute([':submission_id' => $response['id']]);
    $values = [];
    foreach ($valueStmt->fetchAll() as $valueRow) {
        $values[$valueRow['field_id']] = format_value_for_display($valueRow['value']);
    }
    $row = [(int) $response['id'], $response['created_at']];
    foreach ($fields as $field) {
        $row[] = $values[$field['id']] ?? '';
    }
    fputcsv($output, $row, ';');
}
fclose($output);
exit;
