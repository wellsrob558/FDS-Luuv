<?php
require_once __DIR__ . '/../../config/config.php';
require_login();
require_role(['super_admin', 'editor']);
$formId = (int) get('form_id');
$id = (int) get('id');

$formStmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id');
$formStmt->execute([':id' => $formId]);
$form = $formStmt->fetch();

$responseStmt = $pdo->prepare('SELECT * FROM submissions WHERE id = :id AND form_id = :form_id');
$responseStmt->execute([':id' => $id, ':form_id' => $formId]);
$response = $responseStmt->fetch();
if (!$form || !$response) {
    exit('Registro não encontrado.');
}

$fieldStmt = $pdo->prepare('SELECT * FROM form_fields WHERE form_id = :form_id ORDER BY sort_order ASC, id ASC');
$fieldStmt->execute([':form_id' => $formId]);
$fields = $fieldStmt->fetchAll();

$valuesStmt = $pdo->prepare('SELECT field_id, value_text, value_json FROM submission_values WHERE submission_id = :submission_id');
$valuesStmt->execute([':submission_id' => $id]);
$currentValues = [];
foreach ($valuesStmt->fetchAll() as $row) {
    $currentValues[$row['field_id']] = $row['value_json'] ?: $row['value_text'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $errors = [];
    foreach ($fields as $field) {
        if ((int) $field['is_active'] !== 1) {
            continue;
        }
        $incoming = $_POST['field'][$field['id']] ?? '';
        if ($field['field_type'] === 'checkbox') {
            $incoming = $_POST['field'][$field['id']] ?? [];
        }
        if ($error = validate_field_value($field, $incoming)) {
            $errors[] = $error;
        }
    }
    if (empty($errors)) {
        $before = fetch_submission_snapshot($pdo, $id);
        foreach ($fields as $field) {
            $incoming = $_POST['field'][$field['id']] ?? '';
            if ($field['field_type'] === 'checkbox') {
                $incoming = $_POST['field'][$field['id']] ?? [];
            }
            upsert_submission_value($pdo, $id, $field['id'], sanitize_input($incoming));
        }
        $pdo->prepare('UPDATE submissions SET updated_at = NOW() WHERE id = :id')->execute([':id' => $id]);
        audit_log($pdo, 'update', 'submission', $id, 'Editou uma resposta.', $before, fetch_submission_snapshot($pdo, $id));
        flash('success', 'Resposta atualizada com sucesso.');
        redirect('/admin/responses/index.php?form_id=' . $formId);
    }
    flash('error', implode(' ', $errors));
}

$title = 'Editar resposta';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header"><div><h1 class="page-title">Editar resposta #<?= (int) $id ?></h1></div></div>
<div class="card">
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <?php foreach ($fields as $field): ?>
            <?php $rawValue = $currentValues[$field['id']] ?? $field['default_value']; $decoded = json_decode((string)$rawValue, true); $options = json_decode((string)$field['options_json'], true) ?: []; ?>
            <div class="form-group">
                <label><?= e($field['label']) ?></label>
                <?php if ($field['field_type'] === 'textarea'): ?>
                    <textarea name="field[<?= $field['id'] ?>]"><?= e(is_array($decoded) ? implode(', ', $decoded) : $rawValue) ?></textarea>
                <?php elseif ($field['field_type'] === 'select'): ?>
                    <select name="field[<?= $field['id'] ?>]">
                        <option value="">Selecione</option>
                        <?php foreach ($options as $option): ?>
                            <option value="<?= e($option['value']) ?>" <?= (string)$rawValue === (string)$option['value'] ? 'selected' : '' ?>><?= e($option['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php elseif ($field['field_type'] === 'radio'): ?>
                    <?php foreach ($options as $option): ?>
                        <label><input type="radio" name="field[<?= $field['id'] ?>]" value="<?= e($option['value']) ?>" <?= (string)$rawValue === (string)$option['value'] ? 'checked' : '' ?>> <?= e($option['label']) ?></label><br>
                    <?php endforeach; ?>
                <?php elseif ($field['field_type'] === 'checkbox'): ?>
                    <?php $decoded = is_array($decoded) ? $decoded : []; foreach ($options as $option): ?>
                        <label><input type="checkbox" name="field[<?= $field['id'] ?>][]" value="<?= e($option['value']) ?>" <?= in_array($option['value'], $decoded, true) ? 'checked' : '' ?>> <?= e($option['label']) ?></label><br>
                    <?php endforeach; ?>
                <?php else: ?>
                    <input type="<?= e($field['field_type']) ?>" name="field[<?= $field['id'] ?>]" value="<?= e(is_array($decoded) ? implode(', ', $decoded) : $rawValue) ?>">
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <div class="actions">
            <button class="btn" type="submit">Salvar</button>
            <a class="btn btn-light" href="<?= admin_url('/responses/index.php?form_id=' . $formId) ?>">Cancelar</a>
        </div>
    </form>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
