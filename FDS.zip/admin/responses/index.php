<?php
require_once __DIR__ . '/../../config/config.php';
require_login();

$formId = (int) get('form_id');
$formStmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id');
$formStmt->execute([':id' => $formId]);
$form = $formStmt->fetch();
if (!$form) {
    exit('Formulário não encontrado.');
}

$fieldsStmt = $pdo->prepare('SELECT * FROM form_fields WHERE form_id = :form_id ORDER BY sort_order ASC, id ASC');
$fieldsStmt->execute([':form_id' => $formId]);
$fields = $fieldsStmt->fetchAll();

$page = max(1, (int) get('page', 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;
$search = get('search');
$order = get('order', 'created_at');
$direction = strtoupper(get('direction', 'DESC')) === 'ASC' ? 'ASC' : 'DESC';
$allowedOrder = ['id', 'created_at', 'updated_at'];
if (!in_array($order, $allowedOrder, true)) {
    $order = 'created_at';
}

$countSql = 'SELECT COUNT(DISTINCT s.id) FROM submissions s LEFT JOIN submission_values sv ON sv.submission_id = s.id WHERE s.form_id = :form_id';
$listSql = 'SELECT DISTINCT s.* FROM submissions s LEFT JOIN submission_values sv ON sv.submission_id = s.id WHERE s.form_id = :form_id';
$params = [':form_id' => $formId];
if ($search !== '') {
    $countSql .= ' AND sv.value_text LIKE :search';
    $listSql .= ' AND sv.value_text LIKE :search';
    $params[':search'] = '%' . $search . '%';
}
$listSql .= " ORDER BY s.$order $direction LIMIT $perPage OFFSET $offset";

$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();
$totalPages = max(1, (int) ceil($total / $perPage));
$listStmt = $pdo->prepare($listSql);
$listStmt->execute($params);
$responses = $listStmt->fetchAll();

$title = 'Respostas';
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Respostas: <?= e($form['title']) ?></h1>
        <p class="muted">CRUD dinâmico das respostas deste formulário.</p>
    </div>
    <div class="actions">
        <a class="btn btn-secondary" href="<?= admin_url('/responses/export.php?form_id=' . $formId . '&type=csv') ?>">Exportar CSV</a>
        <a class="btn btn-secondary" href="<?= admin_url('/responses/export.php?form_id=' . $formId . '&type=xls') ?>">Exportar Excel</a>
    </div>
</div>
<div class="card">
    <form class="search-bar" method="get">
        <input type="hidden" name="form_id" value="<?= (int) $formId ?>">
        <input type="text" name="search" placeholder="Buscar nas respostas" value="<?= e($search) ?>">
        <select name="order">
            <option value="created_at" <?= $order === 'created_at' ? 'selected' : '' ?>>Criado em</option>
            <option value="updated_at" <?= $order === 'updated_at' ? 'selected' : '' ?>>Atualizado em</option>
            <option value="id" <?= $order === 'id' ? 'selected' : '' ?>>ID</option>
        </select>
        <select name="direction">
            <option value="DESC" <?= $direction === 'DESC' ? 'selected' : '' ?>>Descendente</option>
            <option value="ASC" <?= $direction === 'ASC' ? 'selected' : '' ?>>Ascendente</option>
        </select>
        <button class="btn" type="submit">Filtrar</button>
    </form>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Criado em</th>
                    <?php foreach (array_slice($fields, 0, 3) as $field): ?>
                        <th><?= e($field['label']) ?></th>
                    <?php endforeach; ?>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($responses as $response): ?>
                    <?php
                    $valueStmt = $pdo->prepare('SELECT ff.label, ff.id AS field_id, COALESCE(sv.value_text, sv.value_json) AS value FROM submission_values sv INNER JOIN form_fields ff ON ff.id = sv.field_id WHERE sv.submission_id = :submission_id ORDER BY ff.sort_order ASC, ff.id ASC');
                    $valueStmt->execute([':submission_id' => $response['id']]);
                    $values = $valueStmt->fetchAll();
                    ?>
                    <tr>
                        <td>#<?= (int) $response['id'] ?></td>
                        <td><?= e(date('d/m/Y H:i', strtotime($response['created_at']))) ?></td>
                        <?php foreach (array_slice($values, 0, 3) as $value): ?>
                            <td><?= e(mb_strimwidth((string) format_value_for_display($value['value']), 0, 40, '...')) ?></td>
                        <?php endforeach; ?>
                        <td>
                            <div class="actions">
                                <a class="btn btn-light" href="<?= admin_url('/responses/view.php?form_id=' . $formId . '&id=' . $response['id']) ?>">Ver</a>
                                <a class="btn btn-secondary" href="<?= admin_url('/responses/edit.php?form_id=' . $formId . '&id=' . $response['id']) ?>">Editar</a>
                                <a class="btn btn-danger js-confirm" data-confirm="Excluir esta resposta?" href="<?= admin_url('/responses/delete.php?form_id=' . $formId . '&id=' . $response['id']) ?>">Excluir</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <?php if ($i === $page): ?>
                <span><?= $i ?></span>
            <?php else: ?>
                <a href="?form_id=<?= $formId ?>&search=<?= urlencode($search) ?>&order=<?= urlencode($order) ?>&direction=<?= urlencode($direction) ?>&page=<?= $i ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
