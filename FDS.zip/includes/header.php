<?php
require_once __DIR__ . '/../config/config.php';
$title = $title ?? APP_NAME;
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> - <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bellota+Text:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</head>
<body>
<div class="app-shell">
    <?php if (is_logged_in()): ?>
    <aside class="sidebar">
        <div class="brand"><img src="logo.png" width="80%" style="border-radius: 5%; box-shadow: 10px 10px 2px 1px rgba(0, 0, 0, 0.1);"></div>
        <nav>
            <a href="<?= admin_url('/dashboard.php') ?>">Dashboard</a>
            <a href="<?= admin_url('/forms/index.php') ?>">Formulários</a>
            <a href="<?= BASE_URL ?>/public/index.php">Formulários públicos</a>
            <a href="<?= BASE_URL ?>/auth/logout.php">Sair</a>
        </nav>
        <div class="sidebar-user">
            <strong><?= e(current_user()['name']) ?></strong>
            <small><?= e(current_user()['role']) ?></small>
        </div>
    </aside>
    <?php endif; ?>
    <main class="content <?= is_logged_in() ? '' : 'content-full' ?>">
        <?php if ($message = flash('success')): ?>
            <div class="alert alert-success"><?= e($message) ?></div>
        <?php endif; ?>
        <?php if ($message = flash('error')): ?>
            <div class="alert alert-danger"><?= e($message) ?></div>
        <?php endif; ?>
