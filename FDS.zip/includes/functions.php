<?php
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect($path)
{
    header('Location: ' . BASE_URL . $path);
    exit;
}

function flash($key, $message = null)
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }

    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }

    return null;
}

function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf()
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            exit('Token CSRF inválido.');
        }
    }
}

function slugify($text)
{
    $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return $text ?: 'formulario-' . time();
}

function post($key, $default = '')
{
    return trim($_POST[$key] ?? $default);
}

function get($key, $default = '')
{
    return trim($_GET[$key] ?? $default);
}

function bool_to_int($value)
{
    return $value ? 1 : 0;
}

function is_checked($key)
{
    return isset($_POST[$key]) ? 1 : 0;
}

function admin_url($path = '')
{
    return BASE_URL . '/admin' . $path;
}

function public_form_url($slug)
{
    return BASE_URL . '/public/form.php?slug=' . urlencode($slug);
}

function form_cover_url($filename)
{
    $filename = basename((string) $filename);
    if ($filename === '') {
        return '';
    }
    return BASE_URL . '/assets/uploads/covers/' . rawurlencode($filename);
}

function ensure_directory($path)
{
    if (!is_dir($path)) {
        mkdir($path, 0775, true);
    }
}

function remove_uploaded_file_if_exists($path)
{
    if ($path && is_file($path)) {
        @unlink($path);
    }
}

function handle_form_cover_upload($inputName = 'cover_image')
{
    if (empty($_FILES[$inputName]) || !is_array($_FILES[$inputName])) {
        return null;
    }

    $file = $_FILES[$inputName];
    if (($file['error'] ?? 4) === 4) {
        return null;
    }

    if (($file['error'] ?? 0) !== 0) {
        throw new RuntimeException('Erro ao enviar a imagem de capa.');
    }

    if (($file['size'] ?? 0) > MAX_UPLOAD_SIZE) {
        throw new RuntimeException('A imagem de capa excede o limite permitido.');
    }

    ensure_directory(FORM_COVER_DIR);

    $mime = mime_content_type($file['tmp_name']);
    $extensions = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    if (!isset($extensions[$mime])) {
        throw new RuntimeException('A capa deve ser uma imagem JPG, PNG ou WEBP.');
    }

    $filename = uniqid('cover_', true) . '.' . $extensions[$mime];
    $target = FORM_COVER_DIR . $filename;
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        throw new RuntimeException('Não foi possível salvar a imagem de capa.');
    }

    return $filename;
}

function render_status_badge($status)
{
    return $status ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge badge-danger">Inativo</span>';
}

function render_availability_badge($status)
{
    $map = [
        'open' => ['Aberto', 'badge-success'],
        'scheduled' => ['Agendado', 'badge-warning'],
        'expired' => ['Encerrado', 'badge-danger'],
        'limit_reached' => ['Limite atingido', 'badge-danger'],
        'inactive' => ['Inativo', 'badge-dark'],
    ];
    [$label, $class] = $map[$status] ?? ['Indefinido', 'badge-dark'];
    return '<span class="badge ' . $class . '">' . e($label) . '</span>';
}

function get_field_types()
{
    return [
        'text' => 'Texto simples',
        'textarea' => 'Texto longo',
        'number' => 'Número',
        'email' => 'E-mail',
        'phone' => 'Telefone',
        'date' => 'Data',
        'time' => 'Hora',
        'select' => 'Select',
        'radio' => 'Radio button',
        'checkbox' => 'Checkbox',
        'file' => 'Upload de arquivo',
        'password' => 'Senha',
        'url' => 'URL',
    ];
}

function get_role_options()
{
    return [
        'super_admin' => 'Super admin',
        'editor' => 'Editor',
        'viewer' => 'Visualizador',
    ];
}

function role_label($role)
{
    $roles = get_role_options();
    return $roles[$role] ?? $role;
}

function parse_options($input)
{
    $lines = preg_split('/\r\n|\r|\n/', (string) $input);
    $options = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        if (strpos($line, '|') !== false) {
            [$value, $label] = array_map('trim', explode('|', $line, 2));
        } else {
            $value = $label = $line;
        }
        $options[] = ['value' => $value, 'label' => $label];
    }
    return json_encode($options, JSON_UNESCAPED_UNICODE);
}

function field_options_as_text($json)
{
    $items = json_decode((string) $json, true) ?: [];
    $lines = [];
    foreach ($items as $item) {
        $lines[] = ($item['value'] ?? '') . '|' . ($item['label'] ?? '');
    }
    return implode(PHP_EOL, $lines);
}

function format_value_for_display($value)
{
    if (is_string($value) && preg_match('/^\[.*\]$/', $value)) {
        $decoded = json_decode($value, true);
        if (is_array($decoded)) {
            return implode(', ', $decoded);
        }
    }
    return $value;
}

function sanitize_input($value)
{
    if (is_array($value)) {
        return array_map('sanitize_input', $value);
    }
    return trim(strip_tags((string) $value));
}

function null_if_empty($value)
{
    return trim((string) $value) === '' ? null : trim((string) $value);
}

function positive_int_or_null($value)
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }

    return max(1, (int) $value);
}

function datetime_local_to_db($value)
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }

    $date = DateTime::createFromFormat('Y-m-d\TH:i', $value);
    if (!$date) {
        try {
            $date = new DateTime($value);
        } catch (Throwable $e) {
            return null;
        }
    }

    return $date->format('Y-m-d H:i:s');
}

function db_datetime_to_local($value)
{
    if (!$value) {
        return '';
    }

    try {
        return (new DateTime($value))->format('Y-m-d\TH:i');
    } catch (Throwable $e) {
        return '';
    }
}

function format_datetime_br($value, $withTime = true)
{
    if (!$value) {
        return '—';
    }

    try {
        return (new DateTime($value))->format($withTime ? 'd/m/Y H:i' : 'd/m/Y');
    } catch (Throwable $e) {
        return (string) $value;
    }
}

function validate_form_schedule($availableFrom, $availableUntil)
{
    if ($availableFrom && $availableUntil && strtotime($availableUntil) <= strtotime($availableFrom)) {
        return 'A data/hora de encerramento precisa ser maior que a data/hora de abertura.';
    }

    return null;
}

function get_form_response_count(PDO $pdo, $formId)
{
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM submissions WHERE form_id = :form_id');
    $stmt->execute([':form_id' => $formId]);
    return (int) $stmt->fetchColumn();
}

function get_form_availability(PDO $pdo, array $form)
{
    $responseCount = array_key_exists('responses_count', $form)
        ? (int) $form['responses_count']
        : get_form_response_count($pdo, $form['id']);

    $maxResponses = isset($form['max_responses']) && $form['max_responses'] !== null
        ? (int) $form['max_responses']
        : null;

    $now = new DateTimeImmutable();
    $availableFrom = !empty($form['available_from']) ? new DateTimeImmutable($form['available_from']) : null;
    $availableUntil = !empty($form['available_until']) ? new DateTimeImmutable($form['available_until']) : null;

    $status = 'open';
    $reason = 'Recebendo respostas normalmente.';

    if ((int) ($form['is_active'] ?? 0) !== 1) {
        $status = 'inactive';
        $reason = 'Este formulário está inativo no momento.';
    } elseif ($availableFrom && $now < $availableFrom) {
        $status = 'scheduled';
        $reason = 'Este formulário abre em ' . $availableFrom->format('d/m/Y H:i') . '.';
    } elseif ($availableUntil && $now > $availableUntil) {
        $status = 'expired';
        $reason = 'Este formulário foi encerrado em ' . $availableUntil->format('d/m/Y H:i') . '.';
    } elseif ($maxResponses !== null && $responseCount >= $maxResponses) {
        $status = 'limit_reached';
        $reason = 'O limite de respostas deste formulário foi atingido.';
    }

    return [
        'status' => $status,
        'is_open' => $status === 'open',
        'reason' => $reason,
        'responses_count' => $responseCount,
        'max_responses' => $maxResponses,
        'remaining_responses' => $maxResponses !== null ? max(0, $maxResponses - $responseCount) : null,
        'available_from' => $availableFrom?->format('Y-m-d H:i:s'),
        'available_until' => $availableUntil?->format('Y-m-d H:i:s'),
    ];
}

function validate_field_value($field, $value)
{
    $type = $field['field_type'];
    $label = $field['label'];
    $required = (int) $field['is_required'] === 1;
    $cleanValue = is_array($value) ? $value : trim((string) $value);

    if ($required) {
        $isEmpty = is_array($cleanValue) ? empty($cleanValue) : $cleanValue === '';
        if ($isEmpty) {
            return "O campo {$label} é obrigatório.";
        }
    }

    if (!$required && (is_array($cleanValue) ? empty($cleanValue) : $cleanValue === '')) {
        return null;
    }

    switch ($type) {
        case 'email':
            if (!filter_var($cleanValue, FILTER_VALIDATE_EMAIL)) {
                return "O campo {$label} precisa ser um e-mail válido.";
            }
            break;
        case 'url':
            if (!filter_var($cleanValue, FILTER_VALIDATE_URL)) {
                return "O campo {$label} precisa ser uma URL válida.";
            }
            break;
        case 'number':
            if (!is_numeric($cleanValue)) {
                return "O campo {$label} precisa ser numérico.";
            }
            break;
        case 'date':
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $cleanValue)) {
                return "O campo {$label} precisa ter uma data válida.";
            }
            break;
        case 'time':
            if (!preg_match('/^\d{2}:\d{2}$/', $cleanValue)) {
                return "O campo {$label} precisa ter uma hora válida.";
            }
            break;
    }

    if (!empty($field['validation_rule'])) {
        $pattern = '/' . str_replace('/', '\/', $field['validation_rule']) . '/';
        if (@preg_match($pattern, '') !== false && !preg_match($pattern, is_array($cleanValue) ? implode(',', $cleanValue) : $cleanValue)) {
            return "O campo {$label} não atende à regra de validação.";
        }
    }

    return null;
}

function save_submission_value(PDO $pdo, $submissionId, $fieldId, $value)
{
    $jsonValue = null;
    $textValue = null;

    if (is_array($value)) {
        $jsonValue = json_encode(array_values($value), JSON_UNESCAPED_UNICODE);
        $textValue = implode(', ', $value);
    } else {
        $textValue = (string) $value;
    }

    $stmt = $pdo->prepare('INSERT INTO submission_values (submission_id, field_id, value_text, value_json, created_at, updated_at)
        VALUES (:submission_id, :field_id, :value_text, :value_json, NOW(), NOW())');
    $stmt->execute([
        ':submission_id' => $submissionId,
        ':field_id' => $fieldId,
        ':value_text' => $textValue,
        ':value_json' => $jsonValue,
    ]);
}

function upsert_submission_value(PDO $pdo, $submissionId, $fieldId, $value)
{
    $jsonValue = null;
    $textValue = null;

    if (is_array($value)) {
        $jsonValue = json_encode(array_values($value), JSON_UNESCAPED_UNICODE);
        $textValue = implode(', ', $value);
    } else {
        $textValue = (string) $value;
    }

    $stmt = $pdo->prepare('SELECT id FROM submission_values WHERE submission_id = :submission_id AND field_id = :field_id LIMIT 1');
    $stmt->execute([':submission_id' => $submissionId, ':field_id' => $fieldId]);
    $exists = $stmt->fetchColumn();

    if ($exists) {
        $update = $pdo->prepare('UPDATE submission_values SET value_text = :value_text, value_json = :value_json, updated_at = NOW() WHERE id = :id');
        $update->execute([':value_text' => $textValue, ':value_json' => $jsonValue, ':id' => $exists]);
    } else {
        save_submission_value($pdo, $submissionId, $fieldId, $value);
    }
}

function send_notification_email_if_enabled($form, $submissionId)
{
    if (empty($form['notify_email'])) {
        return;
    }

    $to = $form['notify_email'];
    $subject = 'Nova resposta recebida: ' . $form['title'];
    $message = "Uma nova resposta foi enviada para o formulário '{$form['title']}'.\n\nID da resposta: {$submissionId}\nAcesse o painel administrativo para visualizar os detalhes.";
    @mail($to, $subject, $message, 'From: no-reply@example.com');
}

function json_snapshot($data)
{
    if ($data === null) {
        return null;
    }

    return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function audit_log(PDO $pdo, $action, $entityType, $entityId = null, $description = '', $oldValues = null, $newValues = null, $userId = '__auto__')
{
    $resolvedUserId = $userId;
    if ($resolvedUserId === '__auto__' && !empty($_SESSION['user']['id'])) {
        $resolvedUserId = (int) $_SESSION['user']['id'];
    } elseif ($resolvedUserId === '__auto__') {
        $resolvedUserId = null;
    }

    $stmt = $pdo->prepare('INSERT INTO audit_logs (user_id, action, entity_type, entity_id, description, old_values, new_values, ip_address, created_at)
        VALUES (:user_id, :action, :entity_type, :entity_id, :description, :old_values, :new_values, :ip_address, NOW())');
    $stmt->execute([
        ':user_id' => $resolvedUserId,
        ':action' => $action,
        ':entity_type' => $entityType,
        ':entity_id' => $entityId,
        ':description' => $description,
        ':old_values' => json_snapshot($oldValues),
        ':new_values' => json_snapshot($newValues),
        ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
    ]);
}

function refresh_session_user(PDO $pdo, $userId)
{
    if (empty($_SESSION['user']['id']) || (int) $_SESSION['user']['id'] !== (int) $userId) {
        return;
    }

    $stmt = $pdo->prepare('SELECT id, name, email, role, status FROM users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();

    if ($user && (int) $user['status'] === 1) {
        $_SESSION['user'] = $user;
        return;
    }

    unset($_SESSION['user']);
}

function count_active_super_admins(PDO $pdo)
{
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'super_admin' AND status = 1");
    return (int) $stmt->fetchColumn();
}

function fetch_form_snapshot(PDO $pdo, $formId)
{
    $formStmt = $pdo->prepare('SELECT * FROM forms WHERE id = :id LIMIT 1');
    $formStmt->execute([':id' => $formId]);
    $form = $formStmt->fetch();
    if (!$form) {
        return null;
    }

    $fieldStmt = $pdo->prepare('SELECT id, field_type, name, label, placeholder, is_required, default_value, mask, validation_rule, css_class, width, options_json, sort_order, is_active FROM form_fields WHERE form_id = :form_id ORDER BY sort_order ASC, id ASC');
    $fieldStmt->execute([':form_id' => $formId]);
    $form['fields'] = $fieldStmt->fetchAll();
    return $form;
}

function fetch_submission_snapshot(PDO $pdo, $submissionId)
{
    $stmt = $pdo->prepare('SELECT s.*, f.title AS form_title FROM submissions s INNER JOIN forms f ON f.id = s.form_id WHERE s.id = :id LIMIT 1');
    $stmt->execute([':id' => $submissionId]);
    $submission = $stmt->fetch();
    if (!$submission) {
        return null;
    }

    $valueStmt = $pdo->prepare('SELECT ff.label, ff.field_type, COALESCE(sv.value_text, sv.value_json) AS value FROM submission_values sv INNER JOIN form_fields ff ON ff.id = sv.field_id WHERE sv.submission_id = :submission_id ORDER BY ff.sort_order ASC, ff.id ASC');
    $valueStmt->execute([':submission_id' => $submissionId]);
    $submission['values'] = $valueStmt->fetchAll();
    return $submission;
}
