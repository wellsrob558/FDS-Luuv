<?php
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect($path)
{
    header('Location: ' . BASE_URL . $path);
    exit;
}

function flash($key, $message = null)
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }

    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }

    return null;
}

function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf()
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            exit('Token CSRF inválido.');
        }
    }
}

function slugify($text)
{
    $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return $text ?: 'formulario-' . time();
}

function post($key, $default = '')
{
    return trim($_POST[$key] ?? $default);
}

function get($key, $default = '')
{
    return trim($_GET[$key] ?? $default);
}

function bool_to_int($value)
{
    return $value ? 1 : 0;
}

function is_checked($key)
{
    return isset($_POST[$key]) ? 1 : 0;
}

function admin_url($path = '')
{
    return BASE_URL . '/admin' . $path;
}

function public_form_url($slug)
{
    return BASE_URL . '/public/form.php?slug=' . urlencode($slug);
}

function render_status_badge($status)
{
    return $status ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge badge-danger">Inativo</span>';
}

function get_field_types()
{
    return [
        'text' => 'Texto simples',
        'textarea' => 'Texto longo',
        'number' => 'Número',
        'email' => 'E-mail',
        'phone' => 'Telefone',
        'date' => 'Data',
        'time' => 'Hora',
        'select' => 'Select',
        'radio' => 'Radio button',
        'checkbox' => 'Checkbox',
        'file' => 'Upload de arquivo',
        'password' => 'Senha',
        'url' => 'URL',
    ];
}

function parse_options($input)
{
    $lines = preg_split('/\r\n|\r|\n/', (string) $input);
    $options = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        if (strpos($line, '|') !== false) {
            [$value, $label] = array_map('trim', explode('|', $line, 2));
        } else {
            $value = $label = $line;
        }
        $options[] = ['value' => $value, 'label' => $label];
    }
    return json_encode($options, JSON_UNESCAPED_UNICODE);
}

function field_options_as_text($json)
{
    $items = json_decode((string) $json, true) ?: [];
    $lines = [];
    foreach ($items as $item) {
        $lines[] = ($item['value'] ?? '') . '|' . ($item['label'] ?? '');
    }
    return implode(PHP_EOL, $lines);
}

function format_value_for_display($value)
{
    if (is_string($value) && preg_match('/^\[.*\]$/', $value)) {
        $decoded = json_decode($value, true);
        if (is_array($decoded)) {
            return implode(', ', $decoded);
        }
    }
    return $value;
}

function sanitize_input($value)
{
    if (is_array($value)) {
        return array_map('sanitize_input', $value);
    }
    return trim(strip_tags((string) $value));
}

function validate_field_value($field, $value)
{
    $type = $field['field_type'];
    $label = $field['label'];
    $required = (int) $field['is_required'] === 1;
    $cleanValue = is_array($value) ? $value : trim((string) $value);

    if ($required) {
        $isEmpty = is_array($cleanValue) ? empty($cleanValue) : $cleanValue === '';
        if ($isEmpty) {
            return "O campo {$label} é obrigatório.";
        }
    }

    if (!$required && (is_array($cleanValue) ? empty($cleanValue) : $cleanValue === '')) {
        return null;
    }

    switch ($type) {
        case 'email':
            if (!filter_var($cleanValue, FILTER_VALIDATE_EMAIL)) {
                return "O campo {$label} precisa ser um e-mail válido.";
            }
            break;
        case 'url':
            if (!filter_var($cleanValue, FILTER_VALIDATE_URL)) {
                return "O campo {$label} precisa ser uma URL válida.";
            }
            break;
        case 'number':
            if (!is_numeric($cleanValue)) {
                return "O campo {$label} precisa ser numérico.";
            }
            break;
        case 'date':
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $cleanValue)) {
                return "O campo {$label} precisa ter uma data válida.";
            }
            break;
        case 'time':
            if (!preg_match('/^\d{2}:\d{2}$/', $cleanValue)) {
                return "O campo {$label} precisa ter uma hora válida.";
            }
            break;
    }

    if (!empty($field['validation_rule'])) {
        $pattern = '/' . str_replace('/', '\/', $field['validation_rule']) . '/';
        if (@preg_match($pattern, '') !== false && !preg_match($pattern, is_array($cleanValue) ? implode(',', $cleanValue) : $cleanValue)) {
            return "O campo {$label} não atende à regra de validação.";
        }
    }

    return null;
}

function save_submission_value(PDO $pdo, $submissionId, $fieldId, $value)
{
    $jsonValue = null;
    $textValue = null;

    if (is_array($value)) {
        $jsonValue = json_encode(array_values($value), JSON_UNESCAPED_UNICODE);
        $textValue = implode(', ', $value);
    } else {
        $textValue = (string) $value;
    }

    $stmt = $pdo->prepare('INSERT INTO submission_values (submission_id, field_id, value_text, value_json, created_at, updated_at)
        VALUES (:submission_id, :field_id, :value_text, :value_json, NOW(), NOW())');
    $stmt->execute([
        ':submission_id' => $submissionId,
        ':field_id' => $fieldId,
        ':value_text' => $textValue,
        ':value_json' => $jsonValue,
    ]);
}

function upsert_submission_value(PDO $pdo, $submissionId, $fieldId, $value)
{
    $jsonValue = null;
    $textValue = null;

    if (is_array($value)) {
        $jsonValue = json_encode(array_values($value), JSON_UNESCAPED_UNICODE);
        $textValue = implode(', ', $value);
    } else {
        $textValue = (string) $value;
    }

    $stmt = $pdo->prepare('SELECT id FROM submission_values WHERE submission_id = :submission_id AND field_id = :field_id LIMIT 1');
    $stmt->execute([':submission_id' => $submissionId, ':field_id' => $fieldId]);
    $exists = $stmt->fetchColumn();

    if ($exists) {
        $update = $pdo->prepare('UPDATE submission_values SET value_text = :value_text, value_json = :value_json, updated_at = NOW() WHERE id = :id');
        $update->execute([':value_text' => $textValue, ':value_json' => $jsonValue, ':id' => $exists]);
    } else {
        save_submission_value($pdo, $submissionId, $fieldId, $value);
    }
}

function send_notification_email_if_enabled($form, $submissionId)
{
    if (empty($form['notify_email'])) {
        return;
    }

    $to = $form['notify_email'];
    $subject = 'Nova resposta recebida: ' . $form['title'];
    $message = "Uma nova resposta foi enviada para o formulário '{$form['title']}'.\n\nID da resposta: {$submissionId}\nAcesse o painel administrativo para visualizar os detalhes.";
    @mail($to, $subject, $message, 'From: no-reply@example.com');
}
