<?php
function current_user()
{
    return $_SESSION['user'] ?? null;
}

function is_logged_in()
{
    return !empty($_SESSION['user']);
}

function require_login()
{
    if (!is_logged_in()) {
        flash('error', 'Faça login para continuar.');
        redirect('/auth/login.php');
    }
}

function has_role($roles)
{
    $user = current_user();
    if (!$user) {
        return false;
    }
    $roles = (array) $roles;
    return in_array($user['role'], $roles, true);
}

function require_role($roles)
{
    if (!has_role($roles)) {
        exit('Acesso negado.');
    }
}

function authenticate(PDO $pdo, $email, $password)
{
    $stmt = $pdo->prepare('SELECT id, name, email, password_hash, role, status FROM users WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    if ($user && (int) $user['status'] === 1 && password_verify($password, $user['password_hash'])) {
        unset($user['password_hash']);
        $_SESSION['user'] = $user;
        session_regenerate_id(true);
        return true;
    }

    return false;
}

function logout_user()
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
